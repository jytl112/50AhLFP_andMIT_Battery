import tensorflow as tf
from tensorflow import keras
Ea_min,Ea_max=28000.,40000.
class PD_PINN_Model_Strict(keras.Model):
    def __init__(self, num_op_features, temp_scaler, 
                 param_net_hidden_dim=128, param_net_layers=25,
                 f_theta_hidden_dim=16, f_theta_layers=2, **kwargs):
        super(PD_PINN_Model_Strict, self).__init__(**kwargs)
        self.num_op_features = num_op_features
        self.temp_scaler = temp_scaler
        self.param_net_hidden_dim = param_net_hidden_dim
        self.param_net_layers = param_net_layers
        self.f_theta_hidden_dim = f_theta_hidden_dim
        self.f_theta_layers = f_theta_layers
        self.F_theta_net = self._build_f_theta_net()
        self.Param_net_base = self._build_param_net_base()
        self.soh_head = keras.layers.Dense(1, activation='sigmoid', name='SOH_Head')
        # 【返璞归真】: 回归到单专家物理参数头
        self.A_prime_head = keras.layers.Dense(1, activation='softplus', name='A_prime_Head')
        self.Ea_head = keras.layers.Dense(1, activation=None, name='Ea_Head')
        self.z_head = keras.layers.Dense(1, activation='sigmoid', name='z_Head')
    
    def _build_f_theta_net(self):
        layers_list = [keras.layers.Dense(self.f_theta_hidden_dim, activation='tanh') for _ in range(self.f_theta_layers)]
        layers_list.append(keras.layers.Dense(1, activation='softplus', name='F_theta_Output'))
        return keras.Sequential(layers_list, name='F_theta_Net')

    def _build_param_net_base(self):
        model = keras.Sequential(name='Param_Net_Base')
        input_dim = self.num_op_features + 1
        model.add(keras.layers.Input(shape=(input_dim,)))
        model.add(keras.layers.Dense(self.param_net_hidden_dim, activation='tanh'))
        for _ in range(self.param_net_layers - 1):
             model.add(keras.layers.Dense(self.param_net_hidden_dim, activation='tanh'))
        return model

    def call(self, inputs):
        nn_inputs, phy_inputs = inputs
        op_features = nn_inputs[:, :self.num_op_features]
        n_input = nn_inputs[:, self.num_op_features:]
        L_acc_input = phy_inputs

        param_net_input = tf.concat([op_features, n_input], axis=1)
        base_output = self.Param_net_base(param_net_input)
        
        soh_pred_scaled = self.soh_head(base_output)
        
        parameter_features = tf.concat([base_output, soh_pred_scaled], axis=1)
        
        # 【返璞归真】: 使用单专家头进行预测
        A_prime = self.A_prime_head(parameter_features)
        Ea_raw = self.Ea_head(parameter_features)
        z = self.z_head(parameter_features)

        Ea = Ea_min + (Ea_max - Ea_min) * tf.nn.sigmoid(Ea_raw)
        F_theta_val = self.F_theta_net(op_features)
        
        R = 8.314; epsilon = 1e-8; C_nominal = 1.1
        T_scaled = op_features[:, -1:]
        min_val = tf.constant(self.temp_scaler.min_[0], dtype=tf.float32); scale_val = tf.constant(self.temp_scaler.scale_[0], dtype=tf.float32)
        T_celsius = (T_scaled - min_val) / scale_val
        T_kelvin = T_celsius + 273.15
        z_scaled = z * 0.5 + 0.5
        B_abs_on_z = tf.pow(A_prime, 1.0 / z_scaled)
        stable_L_acc = tf.maximum(L_acc_input, epsilon)
        base_term = B_abs_on_z * tf.exp(-Ea / (R * T_kelvin * z_scaled)) * z_scaled * tf.pow(stable_L_acc, (z_scaled - 1.0) / z_scaled)
        correction_term = C_nominal - stable_L_acc
        L_model = base_term * correction_term * F_theta_val
        return soh_pred_scaled, L_model, A_prime, Ea, z_scaled

# ===================================================================
#                      主执行流程 (已修正)
# ===================================================================
