from pathlib import Path
from types import SimpleNamespace
import os
os.environ.setdefault('CUDA_VISIBLE_DEVICES','-1')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','3')
import json,hashlib,time,argparse
import numpy as np,pandas as pd,tensorflow as tf
from tensorflow import keras

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent/'results'
REFERENCE=BASE.parent/'inputs/MIT_source'
TARGET=BASE.parent/'inputs/50Ah_target.xlsx'
FEATURES=['V_fc_avg','I_fc_avg','V_d_avg','I_d_avg','Temperature','Cycle']
tf.config.threading.set_intra_op_parallelism_threads(2)
tf.config.threading.set_inter_op_parallelism_threads(1)
tf.get_logger().setLevel('ERROR')
keras.utils.set_random_seed(42)
tf.config.experimental.enable_op_determinism()
import sys
sys.path.insert(0,str(REFERENCE))
from Original_PINN_model import PD_PINN_Model_Strict

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load_inputs(label_budget=8):
    d=pd.read_excel(TARGET).sort_values('Cycle').reset_index(drop=True)
    assert len(d)==721 and np.array_equal(d.Cycle,np.arange(1,722))
    config=json.loads((REFERENCE/'source_PINN/config.json').read_text(encoding='utf-8'))
    scale=config['scale'];x=d[FEATURES].copy()
    for col in FEATURES[:-1]:x[col]=x[col].expanding(min_periods=1).mean()
    x[['I_fc_avg','I_d_avg']]*=1.1/50
    xx=((x.to_numpy()-scale['feature_lo'])/scale['feature_span']*2-1).astype('float32')
    # Positions fixed before reading any target SOH labels.
    assert label_budget == 8
    fine_tune_cycles=np.array([1,104,207,310,412,515])
    validation_cycles=np.array([618,721])
    ti=np.flatnonzero(d.Cycle.isin(fine_tune_cycles))
    vi=np.flatnonzero(d.Cycle.isin(validation_cycles))
    assert np.array_equal(d.Cycle.iloc[ti],fine_tune_cycles)
    assert np.array_equal(d.Cycle.iloc[vi],validation_cycles)
    assert len(ti)==6 and len(vi)==2 and len(set(ti)&set(vi))==0
    split=np.full(len(d),'test',dtype='U12');split[ti]='fine_tune';split[vi]='validation'
    # Only the selected labels are accessible to the optimizer/selector.
    yt=d.SOH.iloc[ti].to_numpy('float32')
    yv=d.SOH.iloc[vi].to_numpy('float32')
    source=dict(np.load(REFERENCE/'source_inputs.npz'))
    ix=np.rint(np.linspace(0,len(source['x_train_seq'])-1,64)).astype(int)
    replay_x=source['x_train_seq'][ix,-1,:]
    collocation=np.rint(np.linspace(0,len(d)-1,65)).astype(int)
    protocol={'label_budget':label_budget,'fine_tune_cycles':d.Cycle.iloc[ti].tolist(),
              'validation_cycles':d.Cycle.iloc[vi].tolist(),'test_count':int((split=='test').sum()),
              'selection':'fixed equidistant record positions, no capacity or SOH based selection',
              'source':'MIT Batch1 38 train, b1c17 validation, b1c43 test; previously executed source checkpoint',
              'source_weight_sha256':sha(REFERENCE/'source_PINN/weights.weights.h5'),
              'source_config_sha256':sha(REFERENCE/'source_PINN/config.json'),
              'target_sha256':sha(TARGET),'scale':scale,'no_target_scaler_refit':True,
              'test_labels_used_for_training_or_model_selection':False,
              'full_interval_sparse_calibration_not_future_only_forecasting':True,
              'post_prediction_correction':False,'prediction_smoothing':False,
              'target_labels_smoothed':False,'collocation_uses_operating_inputs_only':True,
              'cumulative_loss_auxiliary':'predicted SOH only, no withheld measured SOH',
              'fixed_source_retention_weight':0.01,'source_retention_points':64,
              'label_preprocessing':'raw SOH at selected points; no centered smoothing',
              'sequence':'five expanding operating means plus current Cycle',
              'target_current_mapping':'source-equivalent amperes, multiply1.1/50',
              'version':'50Ah_early_mid_finetune_late_validation_v2',
              'late_evaluation_count':204,
              'late_validation_used_for_checkpoint_selection':True,
              'unlabelled_full_trajectory_operating_inputs_used_for_physics_collocation':True,
              'future_blind_forecast_claimed':False}
    return d,xx,ti,vi,yt,yv,split,replay_x,collocation,config,protocol

def make_model(config,unfreeze=2):
    scale=config['scale']
    temp=SimpleNamespace(min_=np.array([-1-2*scale['feature_lo'][4]/scale['feature_span'][4]]),scale_=np.array([2/scale['feature_span'][4]]))
    m=PD_PINN_Model_Strict(5,temp,param_net_layers=12,param_net_hidden_dim=96,f_theta_layers=2,f_theta_hidden_dim=16)
    m((np.zeros((2,6),'float32'),np.zeros((2,1),'float32')))
    m.load_weights(REFERENCE/'source_PINN/weights.weights.h5')
    for i,layer in enumerate(m.Param_net_base.layers):layer.trainable=i>=12-unfreeze
    return m

def neural_prediction(m,x,scale):
    y=m((x,np.zeros((len(x),1),'float32')),training=False)[0].numpy().ravel()
    return y*scale['y_span']+scale['y_min']

def execute(label_budget=8,search='all',evaluate_test=True):
    d,x,ti,vi,yt,yv,split,replay_x,ci,config,protocol=load_inputs(label_budget)
    scale=config['scale'];ROOT.mkdir(parents=True,exist_ok=True)
    (ROOT/'Protocol_before_target_training.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    source_model=make_model(config)
    teacher=source_model((replay_x,np.zeros((len(replay_x),1),'float32')),training=False)[0]
    source_all=neural_prediction(source_model,x,scale)
    del source_model
    candidates=[{'unfreeze':2,'lr':2e-5},{'unfreeze':2,'lr':5e-5},
                {'unfreeze':4,'lr':2e-5},{'unfreeze':4,'lr':5e-5},
                {'unfreeze':12,'lr':1e-5},{'unfreeze':12,'lr':2e-5},
                {'unfreeze':12,'lr':5e-5},{'unfreeze':12,'lr':1e-4},
                *[{'unfreeze':12,'lr':lr,'reset_head':True} for lr in [1e-5,2e-5,5e-5,1e-4]]]
    if search=='full':candidates=candidates[4:]
    if search=='reset':candidates=candidates[8:]
    protocol['candidates_prespecified']=candidates
    protocol['fine_tune_max_steps']=3500;protocol['validation_check_every']=20
    protocol['minimum_eligible_step']=200;protocol['patience_checks']=25
    (ROOT/'Protocol_before_target_training.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    records=[];started=time.perf_counter()
    xa=tf.constant(x[ti]);xc=tf.constant(x[ci]);xs=tf.constant(replay_x)
    ys=tf.constant(((yt-scale['y_min'])/scale['y_span'])[:,None],tf.float32)
    dn=tf.constant(np.diff(d.Cycle.iloc[ci].to_numpy('float32'))[:,None])
    best_global=np.inf;selected_model=None;winner=None
    if search=='reset':
        old=json.loads((ROOT/'Training_protocol.json').read_text(encoding='utf-8'))
        winner=old['selected_candidate'];best_global=winner['validation_MAE_pp']
        selected_model=make_model(config,winner['unfreeze'])
        selected_model.load_weights(ROOT/'PINN_sparse_transfer.weights.h5')
    for number,candidate in enumerate(candidates,1):
        keras.utils.set_random_seed(42)
        model=make_model(config,candidate['unfreeze'])
        if candidate.get('reset_head'):
            level=float(np.mean((yt-scale['y_min'])/scale['y_span']))
            level=np.clip(level,1e-4,1-1e-4)
            model.soh_head.kernel.assign(tf.zeros_like(model.soh_head.kernel))
            model.soh_head.bias.assign([np.log(level/(1-level))])
        sigma=[tf.Variable(v,dtype=tf.float32) for v in config['selected_log_weights']]
        variables=model.trainable_variables+sigma
        optimizer=keras.optimizers.Adam(candidate['lr'],clipnorm=1.0);optimizer.build(variables)
        @tf.function
        def update():
            with tf.GradientTape() as tape:
                pa=model((xa,tf.zeros((len(ti),1))),training=True)[0]
                ps=model((xs,tf.zeros((len(replay_x),1))),training=True)[0]
                pred=model((xc,tf.zeros((len(ci),1))),training=True)[0]
                acc=tf.stop_gradient(1.1*(1-(pred*scale['y_span']+scale['y_min'])/100))
                _,physical,ap,ea,z=model((xc,acc),training=True)
                q=(pred*scale['y_span']+scale['y_min'])*1.1/100
                drop=tf.nn.relu(-(q[1:]-q[:-1])/dn)
                loss_data=tf.reduce_mean((pa-ys)**2)+0.01*tf.reduce_mean((ps-teacher)**2)
                losses=[loss_data,tf.reduce_mean((physical[1:]-drop)**2),
                        tf.reduce_mean(tf.nn.relu(ea-40000)+tf.nn.relu(28000-ea)),
                        tf.reduce_mean(((pred[1:]-pred[:-1])/dn)**2)]
                clips=[tf.clip_by_value(v,-10,10) for v in sigma]
                total=tf.add_n([tf.exp(-v)*loss+v for v,loss in zip(clips,losses)])
            grads=tape.gradient(total,variables)
            tf.debugging.assert_all_finite(total,'nonfinite sparse transfer loss')
            optimizer.apply_gradients([(g,v) for g,v in zip(grads,variables) if g is not None])
            return tf.stack(losses)
        history=[];best=np.inf;stale=0;best_weights=None;chosen=0;best_sigma=None
        print('CANDIDATE',number,candidate,'train labels',len(ti),'val',len(vi),flush=True)
        for step in range(1,3501):
            losses=update().numpy()
            if step%20==0 or step==1:
                pv=neural_prediction(model,x[vi],scale)
                validation=float(np.mean(abs(pv-yv)))
                history.append({'step':step,'validation_MAE_pp':validation,
                                **{f'loss_{key}':float(value) for key,value in zip(['data','physics','Ea_range','SOH_smoothness'],losses)}})
                if step>=200:
                    if validation<best-1e-8:
                        best=validation;best_weights=model.get_weights();best_sigma=[float(v.numpy()) for v in sigma];chosen=step;stale=0
                    else:stale+=1
                if step%200==0:
                    print(number,'step',step,'val_MAE_pp',round(validation,6),'elapsed',round(time.perf_counter()-started,1),flush=True)
                if stale>=25:break
        assert best_weights is not None
        model.set_weights(best_weights)
        path=ROOT/f'candidate_{number}';path.mkdir(exist_ok=True)
        model.save_weights(path/'weights.weights.h5')
        pd.DataFrame(history).to_csv(path/'history.csv',index=False)
        record={'candidate':number,**candidate,'selected_step':chosen,'executed_steps':step,
                'validation_MAE_pp':best,'selected_log_weights':best_sigma,'trainable_parameters':int(sum(np.prod(v.shape) for v in model.trainable_variables)),
                'weight_sha256':sha(path/'weights.weights.h5')}
        records.append(record)
        (path/'config.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
        if best<best_global:
            best_global=best;winner=record;selected_model=model
        print('CANDIDATE_DONE',record,flush=True)
    pd.DataFrame(records).to_csv(ROOT/'Validation_only_candidate_selection.csv',index=False)
    assert selected_model is not None
    selected_model.save_weights(ROOT/'PINN_sparse_transfer.weights.h5')
    # Lock architecture, hyperparameters and checkpoint before opening test SOH.
    protocol['selected_candidate']=winner
    protocol['final_weight_sha256']=sha(ROOT/'PINN_sparse_transfer.weights.h5')
    protocol['selection_locked_before_test_evaluation']=True
    protocol['tensorflow']=tf.__version__
    (ROOT/'Training_protocol.json').write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    if not evaluate_test:
        print('VALIDATION_SELECTED_NO_TEST',winner,flush=True)
        return winner
    p=neural_prediction(selected_model,x,scale)
    # Standard forward must not use measured capacity-loss auxiliary values.
    a=selected_model((x[:10],np.zeros((10,1),'float32')))[0].numpy()
    b=selected_model((x[:10],np.full((10,1),0.9,'float32')))[0].numpy()
    assert np.array_equal(a,b)
    truth=d.SOH.to_numpy(float)
    def scores(mask,prediction):
        yy=truth[mask];error=prediction[mask]-yy
        return {'n':len(yy),'MAE_pp':float(np.mean(abs(error))),'RMSE_pp':float(np.sqrt(np.mean(error**2))),
                'MAPE_percent':float(np.mean(abs(error)/yy)*100),'max_abs_error_pp':float(np.max(abs(error)))}
    results={'source_direct_test':scores(split=='test',source_all),
             **{role:scores(split==role,p) for role in ['fine_tune','validation','test']},
             'all721_including_labels':scores(np.ones(len(d),bool),p)}
    frame=pd.DataFrame({'Cycle':d.Cycle,'SOH_raw':truth,'SOH_source_direct':source_all,
                        'SOH_PINN_direct_output':p,'partition':split,'residual_pp':p-truth})
    frame.to_csv(ROOT/'PINN_sparse_transfer_point_predictions.csv',index=False,encoding='utf-8-sig')
    (ROOT/'Final_metrics.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print('FINAL_SELECTED',winner,flush=True)
    print('FINAL_METRICS',json.dumps(results,ensure_ascii=False),flush=True)
    return results

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--label-budget',type=int,choices=[8],default=8)
    ap.add_argument('--search',choices=['all'],default='all');ap.add_argument('--no-test',action='store_true')
    args=ap.parse_args();execute(args.label_budget,args.search,not args.no_test)
