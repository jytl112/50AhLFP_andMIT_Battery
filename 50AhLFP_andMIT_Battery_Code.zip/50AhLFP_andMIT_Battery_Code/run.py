"""Minimal code package: explicit external data, isolated training/prediction outputs."""
from pathlib import Path
import argparse, ast, datetime, json, os, shutil, subprocess, sys

ROOT=Path(__file__).resolve().parent
MIT_MODELS=['PINN','MLP_NoPhysics','LSTM','CNN','Transformer']
LFP_MODELS=['PINN','LSTM','CNN','Transformer']
os.environ['PYTHONIOENCODING']='utf-8'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','3')
sys.dont_write_bytecode=True

def read_json(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def load_paths(path):
    data=read_json(path)
    # Relative paths are interpreted from the code-package root, regardless of cwd.
    return {k:(Path(v) if Path(v).is_absolute() else ROOT/v).resolve() for k,v in data.items()}

def build_plan(task,action,paths,models):
    """Return required source/destination pairs before creating any output folder."""
    plan=[]
    def add(src,dst):plan.append((Path(src),Path(dst)))
    def code(group,dest):
        for p in sorted((ROOT/'code'/group).glob('*.py')):add(p,Path(dest)/p.name)
    if task=='source':
        code('source','inputs/MIT_source')
        for f in ['source_inputs.npz','source_scale.json']:add(paths['source']/f,'inputs/MIT_source/'+f)
        return plan
    code(task,'code')
    if task=='mit':
        archive=paths['mit']
        add(archive/'inputs/MIT.csv','inputs/MIT.csv')
        add(ROOT/'config/mit_protocol.json','inputs/manifest.json')
        if action=='predict':
            add(ROOT/'code/predict_mit.py','code/predict_mit.py')
            for model in models:
                configs=archive/f'selected/{model}_configs.json'
                add(configs,f'selected/{model}_configs.json')
                if not configs.exists():continue
                for cfg in read_json(configs):
                    rel=Path(f'results/{model}/MIT')/cfg['fold']/f'seed{cfg["seed"]}_lr{cfg["lr"]:g}'
                    for file in ['weights.weights.h5','test_predictions.csv']:add(archive/rel/file,rel/file)
        return plan
    archive=paths[task]
    code('source','inputs/MIT_source')
    # The same source array and source checkpoints feed both target protocols.
    for model in LFP_MODELS:
        for file in ['weights.weights.h5','config.json']:
            rel=Path(f'source_{model}')/file;add(paths['source']/rel,Path('inputs/MIT_source')/rel)
    if task=='trajectory':
        add(archive/'inputs/50Ah_target.xlsx','inputs/50Ah_target.xlsx')
        add(paths['source']/'source_inputs.npz','inputs/MIT_source/source_inputs.npz')
        if action=='predict':
            for f in ['Baseline_training_summary.json','Training_protocol.json','Validation_only_candidate_selection.csv','PINN_sparse_transfer.weights.h5']:
                add(archive/'results'/f,Path('results')/f)
            for model in LFP_MODELS[1:]:
                for f in ['Training_protocol.json','Validation_only_candidate_selection.csv','selected.weights.h5','Prediction_before_test_evaluation.csv']:
                    rel=Path('results')/f'baseline_{model}'/f;add(archive/rel,rel)
    else:
        for f in ['operating_inputs.csv','prefix_operating_inputs.csv','six_prefix_labels.csv','heldout_raw_targets.csv']:
            add(archive/'inputs'/f,Path('inputs')/f)
        # Derived at runtime from source_inputs.npz when it is not present.
        replay=paths['source']/'source_training_operating_inputs.npz'
        add(replay if replay.exists() else paths['source']/'source_inputs.npz',
            'inputs/MIT_source/source_training_operating_inputs.npz' if replay.exists() else 'inputs/MIT_source/source_inputs.npz')
        add(ROOT/'config/forecast_protocol.json','Experiment_protocol_before_training.json')
        if action=='predict':
            add(archive/'results/Baseline_training_summary.json','results/Baseline_training_summary.json')
            for model in LFP_MODELS:
                for f in ['Final_training_protocol.json','final.weights.h5','Validation_only_candidate_selection.csv' if model=='PINN' else 'Stage_A_candidates.csv']:
                    rel=Path('results')/model/f;add(archive/rel,rel)
    return plan

def assemble(plan,out):
    for source,relative in plan:
        dest=out/relative;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
    (out/'results').mkdir(exist_ok=True)

def execute(script,args,cwd,log):
    print('Running',script.name,flush=True)
    with log.open('w',encoding='utf-8') as f:
        p=subprocess.Popen([sys.executable,'-W','ignore',str(script),*map(str,args)],cwd=cwd,
            stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace')
        for line in p.stdout:print(line,end='',flush=True);f.write(line);f.flush()
        status=p.wait()
    if status:raise SystemExit(f'Failed ({status}); see {log}')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['check','train','predict'])
    p.add_argument('--task',choices=['all','mit','source','trajectory','multistep'],default='all')
    p.add_argument('--model',choices=['all',*MIT_MODELS],default='all')
    p.add_argument('--paths',type=Path,default=ROOT/'config/data_paths.json',help='JSON mapping mit/source/trajectory/multistep to external archive roots')
    p.add_argument('--output',type=Path,help='New output directory; must not already exist')
    p.add_argument('--check-action',choices=['train','predict'],default='predict')
    a=p.parse_args()
    if a.action=='train' and a.task=='all':p.error('Select a training task with --task mit/source/trajectory/multistep')
    if a.action=='predict' and a.task=='source':p.error('source is a pretraining task; use train --task source')
    if a.task in ['trajectory','multistep','all'] and a.model!='all':p.error('--model applies only to mit and source; target protocols retain all four models')
    if a.task=='source' and a.model=='MLP_NoPhysics':p.error('source models are PINN/LSTM/CNN/Transformer')
    tasks=['mit','trajectory','multistep'] if a.task=='all' else [a.task]
    action=a.check_action if a.action=='check' else a.action
    paths=load_paths(a.paths)
    for name in ['mit','source','trajectory','multistep']:
        if name not in paths:p.error(f'Missing key in paths JSON: {name}')
    plans={};models_by_task={}
    for task in tasks:
        models=(MIT_MODELS if task=='mit' else LFP_MODELS) if a.model=='all' else [a.model]
        models_by_task[task]=models
        plans[task]=build_plan(task,action,paths,models)
    missing=sorted({str(src) for plan in plans.values() for src,_ in plan if not src.is_file()})
    if missing:p.error('Required external files are missing; edit --paths JSON:\n'+'\n'.join(missing))
    if a.action=='check':
        files=list((ROOT/'code').rglob('*.py'))+[Path(__file__)]
        for f in files:ast.parse(f.read_text(encoding='utf-8-sig'),filename=str(f))
        print(f'PASS: {len(files)} Python files compile; all required {action} inputs exist for {tasks}.')
        return
    out=(a.output.resolve() if a.output else ROOT/'runs'/f'{a.action}_{datetime.datetime.now():%Y%m%d_%H%M%S_%f}')
    if out.exists():p.error('Output directory already exists; choose a new one')
    # Protect source archives from accidental output placement inside them.
    for archive in paths.values():
        if out==archive or archive in out.parents:p.error('Output must be outside the external source archives')
    out.mkdir(parents=True)
    for task,plan in plans.items():
        experiment=out/task;assemble(plan,experiment)
        if task=='multistep':
            source=experiment/'inputs/MIT_source';replay=source/'source_training_operating_inputs.npz'
            if not replay.exists():
                import numpy as np
                with np.load(source/'source_inputs.npz',allow_pickle=False) as arrays:
                    np.savez_compressed(replay,x_train_seq=arrays['x_train_seq'])
        code=experiment/'code'
        if task=='source':
            code=experiment/'inputs/MIT_source'
            for model in models_by_task[task]:
                script='train_original_PINN.py' if model=='PINN' else 'Baseline_models.py'
                args=[] if model=='PINN' else [model,'--root',str(code),'--force']
                execute(code/script,args,experiment,experiment/(model+'.log'))
        elif task=='mit':
            if action=='predict':execute(code/'predict_mit.py',['--models',*models_by_task[task]],experiment,experiment/'prediction.log')
            else:
                os.environ['MODEL_COMPARE_DIR']=str(experiment)
                for model in models_by_task[task]:execute(code/'comparison_engine.py',[model,'MIT'],experiment,experiment/(model+'.log'))
        else:
            scripts=(['evaluate_all.py'] if task=='trajectory' else ['forecast.py','evaluate.py']) if action=='predict' else (
                ['train_sparse_transfer.py','train_sparse_baselines.py','evaluate_all.py'] if task=='trajectory' else ['train_pinn.py','train_baselines.py','forecast.py','evaluate.py'])
            for script in scripts:
                args=['--search','all','--no-test'] if script=='train_sparse_transfer.py' else []
                execute(code/script,args,experiment,experiment/(Path(script).stem+'.log'))
    print('Complete. Output:',out,flush=True)

if __name__=='__main__':main()
