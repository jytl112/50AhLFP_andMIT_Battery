"""Score the saved frozen forecasts; this script is the only test-label reader."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd

PACKAGE=Path(__file__).resolve().parent.parent
OUT=PACKAGE/'results'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def evaluate():
    locked=json.loads((OUT/'Forecast_generation_lock.json').read_text(encoding='utf-8'))
    assert locked['heldout_raw_target_file_not_opened']
    assert sha(OUT/'Forecasts_locked_before_raw_target_scoring.csv')==locked['forecast_csv_sha256']
    assert sha(OUT/'Fixed_origin515_tail_locked_before_scoring.csv')==locked['fixed_origin_tail_csv_sha256']
    protocol=json.loads((PACKAGE/'Experiment_protocol_before_training.json').read_text(encoding='utf-8'))
    # First use of future raw SOH/capacity labels in the experiment.
    heldout=pd.read_csv(PACKAGE/'inputs/heldout_raw_targets.csv')
    prefix_labels=pd.read_csv(PACKAGE/'inputs/six_prefix_labels.csv')
    targets=pd.concat([prefix_labels[prefix_labels.Cycle==515],heldout],ignore_index=True).set_index('Cycle')
    reference=protocol['reference_capacity_Ah']
    frame=pd.read_csv(OUT/'Forecasts_locked_before_raw_target_scoring.csv')
    frame['SOH_raw']=targets.loc[frame.target_cycle,'SOH'].to_numpy(float)
    frame['capacity_raw_Ah']=targets.loc[frame.target_cycle,'capacity'].to_numpy(float)
    frame['SOH_raw_origin_persistence']=targets.loc[frame.origin_cycle,'SOH'].to_numpy(float)
    names={'PINN':'SOH_PINN','LSTM':'SOH_LSTM','CNN':'SOH_CNN','Transformer':'SOH_Transformer',
           'Raw origin persistence':'SOH_raw_origin_persistence','Six-label OLS trend':'SOH_six_label_OLS',
           'Sparse six-label persistence':'SOH_sparse_persistence'}
    scores=[]
    for horizon in [1,10,50]:
        rows=frame[frame.horizon==horizon]
        assert len(rows)==157 and rows.origin_cycle.tolist()==list(range(515,672))
        for name,column in names.items():
            error=rows[column].to_numpy(float)-rows.SOH_raw.to_numpy(float)
            scores.append({'horizon':horizon,'model':name,'n_origins':157,
                           'MAE_pp':float(np.mean(abs(error))),'RMSE_pp':float(np.sqrt(np.mean(error**2))),
                           'MAPE_percent':float(np.mean(abs(error)/rows.SOH_raw.to_numpy())*100),
                           'max_abs_error_pp':float(np.max(abs(error))),
                           'MAE_Ah':float(np.mean(abs(error))*reference/100),
                           'RMSE_Ah':float(np.sqrt(np.mean(error**2))*reference/100),
                           'bias_pp':float(np.mean(error)),
                           'target_cycle_first':int(rows.target_cycle.min()),'target_cycle_last':int(rows.target_cycle.max())})
            frame.loc[frame.horizon==horizon,f'error_{name}_pp']=error
    pd.DataFrame(scores).to_csv(OUT/'Multi_step_metrics.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
    frame.to_csv(OUT/'Multi_step_point_errors.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
    tail=pd.read_csv(OUT/'Fixed_origin515_tail_locked_before_scoring.csv')
    tail['SOH_raw']=targets.loc[tail.target_cycle,'SOH'].to_numpy(float)
    tail_scores={}
    for name,column in [('PINN','SOH_PINN'),('LSTM','SOH_LSTM'),('CNN','SOH_CNN'),('Transformer','SOH_Transformer'),
                        ('Six-label OLS trend','SOH_six_label_OLS'),('Origin515 persistence','SOH_origin515_persistence')]:
        error=tail[column].to_numpy()-tail.SOH_raw.to_numpy()
        tail[f'error_{name}_pp']=error
        tail_scores[name]={'n':206,'MAE_pp':float(np.mean(abs(error))),'RMSE_pp':float(np.sqrt(np.mean(error**2))),
                           'MAPE_percent':float(np.mean(abs(error)/tail.SOH_raw)*100)}
    tail.to_csv(OUT/'Fixed_origin515_tail_point_errors.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
    report={'protocol_version':protocol['version'],'horizons':[1,10,50],
            'origin_cycles':[515,671],'origins_per_horizon':157,'records':471,
            'source_checkpoint_reused':True,'last_refit_cycle':515,
            'metrics':scores,'fixed_origin515_tail_metrics':tail_scores,
            'reference_capacity_Ah':reference,'heldout_raw_SO_H_range':{'min':float(heldout.SOH.min()),'max':float(heldout.SOH.max()),'span_pp':float(np.ptp(heldout.SOH))},
            'prospective_or_never_previously_inspected_blind_test_claimed':False,
            'future_operating_condition_assumption':'origin cumulative operating means held constant',
            'no_test_metric_based_model_changes':True,
            'baseline_uses_measured_capacity_at_each_origin':True,
            'overlapping_single_cell_forecasts_not_independent_replicates':True,
            'physical_cells':1,'seed':42,'prediction_lock':locked}
    (OUT/'Multi_step_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(pd.DataFrame(scores)[['horizon','model','MAE_pp','RMSE_pp','MAPE_percent','MAE_Ah']].to_string(index=False))
    return report

if __name__=='__main__':evaluate()
