"""Source models and prefix-only target data for the separate forecast protocol."""
from pathlib import Path
from types import SimpleNamespace
import os,sys,json,hashlib
os.environ.setdefault('CUDA_VISIBLE_DEVICES','-1')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','3')
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
tf.config.threading.set_intra_op_parallelism_threads(2)
tf.config.threading.set_inter_op_parallelism_threads(1)
tf.get_logger().setLevel('ERROR')
keras.utils.set_random_seed(42)
tf.config.experimental.enable_op_determinism()

PACKAGE=Path(__file__).resolve().parent.parent
RESULTS=PACKAGE/'results'
REFERENCE=PACKAGE/'inputs/MIT_source'
FEATURES=['V_fc_avg','I_fc_avg','V_d_avg','I_d_avg','Temperature','Cycle']
sys.path.insert(0,str(REFERENCE))
from Original_PINN_model import PD_PINN_Model_Strict
from Baseline_models import build_model

PINN_CANDIDATES=[{'unfreeze':2,'lr':2e-5},{'unfreeze':2,'lr':5e-5},
                 {'unfreeze':4,'lr':2e-5},{'unfreeze':4,'lr':5e-5},
                 *[{'unfreeze':12,'lr':lr} for lr in [1e-5,2e-5,5e-5,1e-4]],
                 *[{'unfreeze':12,'lr':lr,'reset_head':True} for lr in [1e-5,2e-5,5e-5,1e-4]]]
BASELINE_CANDIDATES=[{'scope':scope,'lr':lr} for scope in ['head','all'] for lr in [1e-5,2e-5,5e-5,1e-4]]
BASELINE_CANDIDATES += [{'scope':'all','lr':lr,'reset_head':True} for lr in [1e-5,2e-5,5e-5,1e-4]]
assert len(PINN_CANDIDATES)==len(BASELINE_CANDIDATES)==12

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save_json(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
def scale_operating(observed,scale):
    ordered=observed.sort_values('Cycle').reset_index(drop=True)
    x=ordered[FEATURES].copy()
    for key in FEATURES[:-1]:x[key]=x[key].expanding(min_periods=1).mean()
    x[['I_fc_avg','I_d_avg']]*=1.1/50
    return ((x.to_numpy()-scale['feature_lo'])/scale['feature_span']*2-1).astype('float32')
def load_development():
    operating=pd.read_csv(PACKAGE/'inputs/prefix_operating_inputs.csv')
    labels=pd.read_csv(PACKAGE/'inputs/six_prefix_labels.csv')
    assert len(operating)==515 and operating.Cycle.max()==515
    assert labels.Cycle.tolist()==[1,104,207,310,412,515]
    assert 'SOH' not in operating.columns and 'capacity' not in operating.columns
    config=json.loads((REFERENCE/'source_PINN/config.json').read_text(encoding='utf-8'))
    x=scale_operating(operating,config['scale'])
    with np.load(REFERENCE/'source_training_operating_inputs.npz',allow_pickle=False) as src:
        assert src.files==['x_train_seq']
        source=src['x_train_seq']
    ix=np.rint(np.linspace(0,len(source)-1,64)).astype(int)
    replay=source[ix]
    ci=np.rint(np.linspace(0,len(operating)-1,65)).astype(int)
    assert ci.max()==514 and len(np.unique(ci))==65
    return operating,labels,x,replay,ci,config
def make_pinn(config,choice,label_values):
    scale=config['scale'];keras.utils.set_random_seed(42)
    temp=SimpleNamespace(min_=np.array([-1-2*scale['feature_lo'][4]/scale['feature_span'][4]]),scale_=np.array([2/scale['feature_span'][4]]))
    m=PD_PINN_Model_Strict(5,temp,param_net_layers=12,param_net_hidden_dim=96,f_theta_layers=2,f_theta_hidden_dim=16)
    m((np.zeros((2,6),'float32'),np.zeros((2,1),'float32')))
    m.load_weights(REFERENCE/'source_PINN/weights.weights.h5')
    for i,layer in enumerate(m.Param_net_base.layers):layer.trainable=i>=12-choice['unfreeze']
    if choice.get('reset_head'):
        level=np.clip(np.mean((np.asarray(label_values)-scale['y_min'])/scale['y_span']),1e-4,1-1e-4)
        m.soh_head.kernel.assign(tf.zeros_like(m.soh_head.kernel));m.soh_head.bias.assign([np.log(level/(1-level))])
    return m
def pinn_predict(m,x,scale):
    return m((x,np.zeros((len(x),1),'float32')),training=False)[0].numpy().ravel()*scale['y_span']+scale['y_min']
def windows8(x):
    padded=np.concatenate([np.repeat(x[:1],7,axis=0),x],axis=0)
    return np.asarray([padded[i:i+8] for i in range(len(x))],dtype='float32')
def forecast_inputs(operating,scale,origin,horizons=(1,10,50)):
    # The only observed rows consulted are at or before this forecast origin.
    past=operating.loc[operating.Cycle<=origin,FEATURES]
    assert len(past)==origin and int(past.Cycle.max())==origin
    observed=scale_operating(past,scale)
    generated=np.repeat(observed[-1:],max(horizons),axis=0)
    cycles=np.arange(origin+1,origin+max(horizons)+1)
    generated[:,5]=((cycles-scale['feature_lo'][5])/scale['feature_span'][5]*2-1).astype('float32')
    combined=np.concatenate([observed,generated],axis=0)
    endpoints=np.asarray([combined[origin+h-1] for h in horizons],dtype='float32')
    sequences=np.asarray([combined[origin+h-8:origin+h] for h in horizons],dtype='float32')
    assert sequences.shape==(len(horizons),8,6)
    return endpoints,sequences
