"""Fine-tune all three source-pretrained baselines using validation labels only.

The six early/middle SOH labels enter the supervised loss. The two late SOH
labels select checkpoints. The remaining target labels are never accessed here.
"""
from pathlib import Path
import json,time,hashlib,datetime
import numpy as np,pandas as pd
from train_sparse_transfer import load_inputs,ROOT,REFERENCE,tf,keras
from Baseline_models import build_model

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save_json(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def execute_baselines():
    d,x,ti,vi,yt,yv,split,replay_x,ci,config,protocol=load_inputs(8)
    scale=config['scale']
    padded=np.concatenate([np.repeat(x[:1],7,axis=0),x],axis=0)
    windows=np.array([padded[i:i+8] for i in range(len(x))],dtype='float32')
    # Read source operating inputs only; no target labels from the source archive.
    with np.load(REFERENCE/'source_inputs.npz',allow_pickle=False) as src:
        source_windows=src['x_train_seq']
        ix=np.rint(np.linspace(0,len(source_windows)-1,64)).astype(int)
        replay=source_windows[ix]
    xs=tf.constant(replay);xa=tf.constant(windows[ti]);ys=tf.constant(((yt-scale['y_min'])/scale['y_span'])[:,None],tf.float32)
    settings=[{'scope':scope,'lr':lr} for scope in ['head','all'] for lr in [1e-5,2e-5,5e-5,1e-4]]
    settings += [{'scope':'all','lr':lr,'reset_head':True} for lr in [1e-5,2e-5,5e-5,1e-4]]
    assert len(settings)==12
    assert d.Cycle.iloc[ti].tolist()==[1,104,207,310,412,515]
    assert d.Cycle.iloc[vi].tolist()==[618,721]
    assert int((split=='test').sum())==713
    ROOT.mkdir(parents=True,exist_ok=True)
    report=[];started=time.perf_counter()
    for name in ['LSTM','CNN','Transformer']:
        out=ROOT/f'baseline_{name}';out.mkdir(exist_ok=True)
        model_started=time.perf_counter()
        model=build_model(name);model(windows[:2]);model.load_weights(REFERENCE/f'source_{name}/weights.weights.h5')
        teacher=model(xs,training=False)
        model_protocol={
            'model':name,'version':protocol['version'],
            'source':protocol['source'],
            'source_weight_sha256':sha(REFERENCE/f'source_{name}/weights.weights.h5'),
            'source_config_sha256':sha(REFERENCE/f'source_{name}/config.json'),
            'source_inputs_sha256':sha(REFERENCE/'source_inputs.npz'),
            'target_sha256':protocol['target_sha256'],
            'target_budget':8,'fine_tune_count':6,'validation_count':2,
            'fine_tune_cycles':d.Cycle.iloc[ti].tolist(),
            'validation_cycles':d.Cycle.iloc[vi].tolist(),'test_count':713,
            'candidate_settings_prespecified':settings,'candidate_count':12,
            'checkpoint_selection':'minimum late-validation raw SOH MAE in percentage points',
            'maximum_updates':3500,'validation_check_every':20,
            'minimum_eligible_update':200,'patience_checks':25,
            'seed':42,'optimizer':'Adam','gradient_clipnorm':1.,
            'loss':'scaled supervised target SOH MSE + 0.01 source teacher retention MSE',
            'source_retention_weight':0.01,'source_retention_points':64,
            'input_window':8,'parameter_count':model.count_params(),
            'early_history_padding':'repeat first observed input to complete causal window',
            'scale':scale,'no_target_scaler_refit':True,
            'target_current_mapping':'source-equivalent amperes, multiply 1.1/50',
            'no_test_label_use_for_selection':True,
            'test_labels_used_for_training_or_model_selection':False,
            'post_prediction_correction':False,'prediction_smoothing':False,
            'late_validation_used_for_checkpoint_selection':True,
            'future_blind_forecast_claimed':False,
            'protocol_written_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        save_json(out/'Protocol_before_training.json',model_protocol)
        best_overall=np.inf;winner=None;chosen_weights=None;records=[]
        for number,choice in enumerate(settings,1):
            keras.utils.set_random_seed(42)
            model=build_model(name);model(windows[:2]);model.load_weights(REFERENCE/f'source_{name}/weights.weights.h5')
            if choice.get('reset_head'):
                head=model.get_layer('SOH_scaled')
                level=np.clip(float(np.mean((yt-scale['y_min'])/scale['y_span'])),1e-4,1-1e-4)
                head.kernel.assign(tf.zeros_like(head.kernel));head.bias.assign([np.log(level/(1-level))])
            for layer in model.layers:layer.trainable=choice['scope']=='all' or layer.name in ['dense32','SOH_scaled']
            opt=keras.optimizers.Adam(choice['lr'],clipnorm=1.0);opt.build(model.trainable_variables)
            @tf.function
            def update():
                with tf.GradientTape() as tape:
                    pa=model(xa,training=True);pr=model(xs,training=True)
                    loss=tf.reduce_mean((pa-ys)**2)+0.01*tf.reduce_mean((pr-teacher)**2)
                tf.debugging.assert_all_finite(loss,'Nonfinite baseline fine-tuning loss')
                gradients=tape.gradient(loss,model.trainable_variables)
                for gradient in gradients:
                    if gradient is not None:
                        tf.debugging.assert_all_finite(gradient,'Nonfinite baseline fine-tuning gradient')
                opt.apply_gradients([(g,v) for g,v in zip(gradients,model.trainable_variables) if g is not None])
                return loss
            best=np.inf;stale=0;weights=None;selected=0;history=[]
            print(name,'CANDIDATE',number,choice,flush=True)
            for step in range(1,3501):
                loss=float(update().numpy())
                if step==1 or step%20==0:
                    p=model(windows[vi],training=False).numpy().ravel()*scale['y_span']+scale['y_min']
                    val=float(np.mean(abs(p-yv)))
                    history.append({'step':step,'loss':loss,'validation_MAE_pp':val})
                    if step>=200:
                        if val<best-1e-8:best=val;stale=0;selected=step;weights=model.get_weights()
                        else:stale+=1
                    if step%400==0:print(name,number,step,'val_MAE',round(val,6),'elapsed',round(time.perf_counter()-started,1),flush=True)
                    if stale>=25:break
            assert weights is not None
            model.set_weights(weights)
            candidate_dir=out/f'candidate_{number}';candidate_dir.mkdir(exist_ok=True)
            model.save_weights(candidate_dir/'weights.weights.h5')
            row={'candidate':number,**choice,'selected_step':selected,'executed_steps':step,
                 'validation_MAE_pp':best,'weight_sha256':sha(candidate_dir/'weights.weights.h5'),
                 'trainable_parameters':int(sum(np.prod(v.shape) for v in model.trainable_variables))}
            records.append(row);pd.DataFrame(history).to_csv(out/f'candidate_{number}_history.csv',index=False)
            save_json(candidate_dir/'config.json',row)
            if best<best_overall:best_overall=best;winner=row;chosen_weights=weights
            print(name,'DONE',row,flush=True)
        assert chosen_weights is not None
        model.set_weights(chosen_weights);model.save_weights(out/'selected.weights.h5')
        assert len(records)==12
        assert winner['validation_MAE_pp']==min(record['validation_MAE_pp'] for record in records)
        row={**model_protocol,**winner,'settings':settings,
             'final_sha256':sha(out/'selected.weights.h5'),
             'selection_locked_before_test_evaluation':True,
             'elapsed_seconds':time.perf_counter()-model_started,
             'tensorflow':tf.__version__}
        save_json(out/'Training_protocol.json',row)
        p=model(windows,training=False).numpy().ravel()*scale['y_span']+scale['y_min']
        assert np.isfinite(p).all()
        pd.DataFrame({'Cycle':d.Cycle,'prediction':p.astype('float64'),'partition':split}).to_csv(
            out/'Prediction_before_test_evaluation.csv',index=False,float_format='%.17g')
        pd.DataFrame(records).to_csv(out/'Validation_only_candidate_selection.csv',index=False)
        report.append(row)
    save_json(ROOT/'Baseline_training_summary.json',report)
    print('ALL_BASELINES_SELECTED_WITHOUT_TEST',
          'elapsed_seconds',round(time.perf_counter()-started,3),flush=True)

if __name__=='__main__':
    execute_baselines()
