# 50 Ah LFP 与 MIT 电池 SOH：精简训练代码

仅保留当前实验所需的 **14 个 Python 文件**、运行配置和依赖清单。包含 MIT 五模型基准、50 Ah 源域预训练、稀疏标定迁移和独立多步预测。省去原始数据、模型权重、训练结果、图像、历史 Notebook、重复日志版本和旧文稿。

代码和数据分开管理。实际训练需要外部输入文件；复算已有预测还需要外部模型权重。当前本机的完整数据位置已填入 `config/data_paths.json`，原数据目录不会被修改。

## 文件用途

|路径|用途|
|---|---|
|`run.py`|检查依赖、组织运行目录、启动训练或预测。|
|`code/mit/comparison_engine.py`|MIT 的 PINN、MLP_NoPhysics、LSTM、CNN、Transformer 统一训练。|
|`code/predict_mit.py`|加载所选 MIT 权重，复算 3 批次 × 3 种子的预测与误差。|
|`code/source/`|50 Ah 迁移实验所用的六维 MIT 源模型与预训练实现。|
|`code/trajectory/`|六点微调、两点验证的 50 Ah 四模型迁移与评价。|
|`code/multistep/`|截至循环 515 的前缀训练、重拟合及 1/10/50 循环预测。|
|`config/`|MIT 数据划分、多步评估协议、外部数据位置。|
|`SOURCE_MANIFEST.json`|核心代码的来源、哈希和整理改动记录。|

训练实现沿用已执行版本，模型结构、损失函数、划分和超参数不作变动。MIT 基准与 50 Ah 迁移网络按各自实现保留。仅增加统一运行入口与 MIT 权重复算入口，并删除 MIT 实现中未使用的绝对路径常量。

## 运行环境

已核实环境：Python 3.13.5、TensorFlow 2.20.0rc0、Keras 3.11.1。主要依赖列在 `requirements.txt`。本机可使用：

```powershell
& 'D:/APP/Anaconda/envs/pytorch/python.exe' '.\run.py' check
```

下列 `python` 均指安装了上述依赖的 Python 环境。使用新环境时可执行 `python -m pip install -r requirements.txt`。命令在解压后的代码根目录运行，也可以用 `run.py` 的绝对路径从其他目录调用。

## 外部输入

`config/data_paths.json` 中包含四个目录：

|键|目录内容|
|---|---|
|`mit`|MIT 包的 `01_benchmark`：`inputs/MIT.csv`；预测还需 `selected/*_configs.json` 及所选 `results` 权重和原预测 CSV。|
|`source`|完整 `inputs/MIT_source`：`source_inputs.npz`、`source_scale.json`，以及 PINN/LSTM/CNN/Transformer 的源域配置与权重。|
|`trajectory`|完整 50 Ah 稀疏标定包：`inputs/50Ah_target.xlsx`；预测还需 `results` 的所选权重、选模记录与协议。|
|`multistep`|完整多步实验包：四份运行输入/标签 CSV；预测还需 `results` 的所选权重、候选和重拟合协议。|

当前 `mit` 指向 `Data_all/50LFP_and_MIT_Pre/MIT_Pre/01_benchmark`。由于 `Data_all` 中的 50 Ah 目录已缺少部分源域输入，另外三项指向仍完整的 `修改/50Ah新预测第二版` 及其子目录。

相对路径均以本代码包根目录为基准。移到其他电脑或从 GitHub 下载后，应修改这些位置；也可用 `--paths 自定义路径配置.json` 提供同样四个键。所需文件缺失时，入口会列出具体文件并停止，不会自动选用其他实验版本。

原始特征提取与历史预处理 Notebook 没有打包；本入口从已经处理并固定划分的训练输入开始。完整实验数据、训练权重和历史结果继续保存在外部原目录。

## 检查与预测

```text
python run.py check
python run.py check --check-action train
python run.py check --task source --check-action train

python run.py predict --task all
python run.py predict --task mit --model PINN
python run.py predict --task trajectory
python run.py predict --task multistep
```

`check` 核对代码语法和对应操作需要的外部文件。`predict` 只加载已保存权重并评分，不启动训练。MIT 还会与归档预测逐点比较；50 Ah 使用原评价流程。多步流程先固定预测再读取后期标签评分。

## 重新训练

```text
python run.py train --task mit --model PINN
python run.py train --task mit --model all

python run.py train --task source --model PINN
python run.py train --task source --model all

python run.py train --task trajectory
python run.py train --task multistep
```

MIT 的 `all` 为五个模型；源域预训练的 `all` 为 PINN、LSTM、CNN、Transformer。两种目标实验固定执行四个模型。目标训练默认复用 `source` 指向的源域检查点；如需使用刚重新训练的源模型，把 `source` 改为对应新输出中的 `source/inputs/MIT_source`。

每次执行都在新的 `runs/操作_时间戳` 下复制必需输入和代码，再产生结果；可通过 `--output 新目录` 指定输出位置。不会覆盖外部原数据或归档权重。运行后产生的数据、权重和结果不属于本次代码压缩包；重新打包时请排除 `runs/`。

## 评价口径与本次验证

- MIT 基准：训练使用因果平滑标签，评价使用原始 SOH；输入包含前一周期容量损失。
- 50 Ah 稀疏标定：循环 1/104/207/310/412/515 微调，618/721 验证，余下 713 条记录评价。
- 50 Ah 多步预测：截至循环 515 训练并冻结，在 157 个共同起点预测提前 1/10/50 循环；未来运行均值保持起点值。

本次检查代码依赖并实际复算已保存权重，未重新完成全量训练。具体核验范围见 `VERIFICATION.json`。
