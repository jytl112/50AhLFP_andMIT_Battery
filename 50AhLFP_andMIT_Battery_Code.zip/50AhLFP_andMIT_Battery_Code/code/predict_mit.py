"""Replay only the requested frozen MIT models, using the unchanged training engine."""
from pathlib import Path
import argparse, json, gc
import numpy as np
import pandas as pd
import comparison_engine as e

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--models',nargs='+',required=True);args=parser.parse_args()
    frame=pd.read_csv(ROOT/'inputs/MIT.csv')
    manifest=json.loads((ROOT/'inputs/manifest.json').read_text(encoding='utf-8'))
    folds={f['fold']:f for f in manifest['folds']};rows=[]
    out=ROOT/'predictions';out.mkdir(exist_ok=True)
    for name in args.models:
        configs=json.loads((ROOT/f'selected/{name}_configs.json').read_text(encoding='utf-8'))
        for cfg in configs:
            fold=folds[cfg['fold']];test=frame[frame.Battery_ID.eq(fold['test_cell'])]
            x,_,_,f=e.windows(test,cfg['scale'])
            e.keras.backend.clear_session();model=e.build_model(name,cfg['scale'],fold['nominal_Ah']);model(x[:2])
            folder=ROOT/f'results/{name}/MIT'/cfg['fold']/f'seed{cfg["seed"]}_lr{cfg["lr"]:g}'
            model.load_weights(folder/'weights.weights.h5')
            prediction=e.inverse(e.output(model,x).numpy(),cfg['scale'])
            archived=pd.read_csv(folder/'test_predictions.csv')
            assert np.array_equal(f.Cycle,archived.Cycle) and np.array_equal(f.SOH_raw,archived.SOH_raw)
            delta=float(np.max(np.abs(prediction-archived.SOH_prediction.to_numpy())))
            assert delta<3e-5,(name,cfg['fold'],cfg['seed'],delta)
            rows.append({'model':name,'fold':cfg['fold'],'seed':cfg['seed'],'max_archived_delta_pp':delta,**e.scores(f.SOH_raw,prediction)})
            result=f[['Battery_ID','Cycle','SOH_raw','SOH_target']].copy();result['SOH_prediction']=prediction
            result.to_csv(out/f'{name}_{cfg["fold"]}_seed{cfg["seed"]}.csv',index=False,encoding='utf-8-sig')
            print('Verified',name,cfg['fold'],cfg['seed'],'delta_pp',delta,flush=True)
            del model;gc.collect()
    pd.DataFrame(rows).to_csv(out/'metrics.csv',index=False,encoding='utf-8-sig')
    print('PASS: verified',len(rows),'MIT model checkpoints',flush=True)

if __name__=='__main__':main()
