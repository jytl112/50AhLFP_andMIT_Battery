"""Evaluate frozen, validation-selected models on the same raw target records."""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd
from train_sparse_transfer import load_inputs, make_model, neural_prediction, ROOT, REFERENCE
from Baseline_models import build_model

NAMES = ['PINN', 'LSTM', 'CNN', 'Transformer']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def evaluate():
    # All architecture choices and best checkpoints must exist before evaluation.
    assert (ROOT/'Baseline_training_summary.json').exists()
    protocols = {'PINN': json.loads((ROOT/'Training_protocol.json').read_text(encoding='utf-8'))}
    selection_audit = []
    for name in NAMES:
        folder = ROOT if name == 'PINN' else ROOT/f'baseline_{name}'
        if name != 'PINN':
            protocols[name] = json.loads((folder/'Training_protocol.json').read_text(encoding='utf-8'))
        protocol = protocols[name]
        winner = protocol['selected_candidate'] if name == 'PINN' else protocol
        choices = pd.read_csv(folder/'Validation_only_candidate_selection.csv')
        assert len(choices) == 12
        best = choices.sort_values(['validation_MAE_pp', 'candidate']).iloc[0]
        assert int(best.candidate) == int(winner['candidate'])
        assert abs(float(best.validation_MAE_pp)-winner['validation_MAE_pp']) < 1e-8
        assert protocol['fine_tune_cycles'] == [1,104,207,310,412,515]
        assert protocol['validation_cycles'] == [618,721]
        weights = folder/('PINN_sparse_transfer.weights.h5' if name == 'PINN' else 'selected.weights.h5')
        expected = protocol['final_weight_sha256'] if name == 'PINN' else protocol['final_sha256']
        assert sha(weights) == expected
        selection_audit.append({'model':name,'candidate':int(best.candidate),'weights_sha256':expected,
                                'validation_only_minimum_verified':True})
    (ROOT/'All_models_locked_before_raw_evaluation.json').write_text(json.dumps(selection_audit,indent=2),encoding='utf-8')

    d,x,ti,vi,yt,yv,partition,replay_x,ci,config,protocol = load_inputs(8)
    scale = config['scale']
    frame = pd.DataFrame({'Cycle':d.Cycle.to_numpy(), 'partition':partition})
    m = make_model(config,protocols['PINN']['selected_candidate']['unfreeze'])
    m.load_weights(ROOT/'PINN_sparse_transfer.weights.h5')
    frame['SOH_PINN'] = neural_prediction(m,x,scale)
    # Measured capacity does not enter the PINN SOH forward branch.
    zeros=np.zeros((10,1),'float32'); arbitrary=np.full((10,1),0.9,'float32')
    assert np.array_equal(m((x[:10],zeros),training=False)[0].numpy(),m((x[:10],arbitrary),training=False)[0].numpy())
    padded=np.concatenate([np.repeat(x[:1],7,axis=0),x],axis=0)
    windows=np.asarray([padded[i:i+8] for i in range(len(x))],dtype='float32')
    for name in NAMES[1:]:
        model=build_model(name); model(windows[:2])
        model.load_weights(ROOT/f'baseline_{name}/selected.weights.h5')
        pred=model(windows,training=False).numpy().ravel()*scale['y_span']+scale['y_min']
        saved=pd.read_csv(ROOT/f'baseline_{name}/Prediction_before_test_evaluation.csv')
        assert np.max(abs(saved.prediction.to_numpy()-pred)) < 1e-9
        frame[f'SOH_{name}']=pred

    # Open the withheld raw SOH column only after all four models are locked.
    truth=d.SOH.to_numpy(float)
    capacity=d.capacity.to_numpy(float)
    reference=float(capacity[0])
    assert np.max(abs(100*capacity/reference-truth)) < 0.00005
    frame.insert(1,'SOH_raw',truth)
    frame.insert(2,'capacity_raw_Ah',capacity)
    for name in NAMES:
        frame[f'error_{name}_pp']=frame[f'SOH_{name}']-truth
    previous=np.r_[np.nan,truth[:-1]]
    # Same six labels, with early-label interpolation and linear late extrapolation.
    anchor_linear=np.interp(d.Cycle,d.Cycle.iloc[ti],yt.astype(float))
    late=d.Cycle.to_numpy()>515
    slope=(float(yt[-1])-float(yt[-2]))/(515-412)
    anchor_linear[late]=float(yt[-1])+slope*(d.Cycle.to_numpy()[late]-515)
    frame['SOH_raw_persistence']=previous
    frame['SOH_six_label_linear']=anchor_linear
    masks={
        'all_evaluation':partition=='test',
        'early_mid_evaluation':(partition=='test')&(d.Cycle.to_numpy()<=515),
        'late_evaluation':(partition=='test')&(d.Cycle.to_numpy()>515),
        'fine_tune':partition=='fine_tune', 'validation':partition=='validation',
    }
    assert [int(masks[k].sum()) for k in ['all_evaluation','early_mid_evaluation','late_evaluation']] == [713,509,204]
    def metrics(pred,mask):
        error=np.asarray(pred)[mask]-truth[mask]
        assert np.isfinite(error).all()
        return {'n':int(mask.sum()), 'MAE_pp':float(np.mean(abs(error))),
                'RMSE_pp':float(np.sqrt(np.mean(error**2))),
                'MAPE_percent':float(np.mean(abs(error)/truth[mask])*100),
                'max_abs_error_pp':float(np.max(abs(error))),
                'MAE_Ah':float(np.mean(abs(error))*reference/100),
                'MAE_Ah_nominal50':float(np.mean(abs(error))/2),
                'bias_pp':float(np.mean(error))}
    by_split={key:{name:metrics(frame[f'SOH_{name}'],mask) for name in NAMES} for key,mask in masks.items()}
    diagnostic={key:{'Raw one-step persistence':metrics(previous,mask),
                     'Six-label linear interpolation/extrapolation':metrics(anchor_linear,mask)}
                for key,mask in masks.items() if 'evaluation' in key}
    ea=m((x,np.zeros((len(x),1),'float32')),training=False)[3].numpy().ravel()
    sigma=np.array(protocols['PINN']['selected_candidate']['selected_log_weights'])
    peak=int(np.argmax(abs(frame.error_PINN_pp.to_numpy())))
    report={
        'version':'50Ah_early_mid_finetune_late_validation_v2',
        'models':NAMES, 'fine_tune_cycles':[1,104,207,310,412,515], 'validation_cycles':[618,721],
        'metrics_by_split':by_split, 'diagnostic_baselines':diagnostic,
        'capacity_reference_Ah':reference,
        'SOH_dynamic_range_pp':float(np.ptp(truth)), 'SOH_min':float(truth.min()),'SOH_max':float(truth.max()),
        'PINN_peak':{'cycle':int(d.Cycle.iloc[peak]),'signed_error_pp':float(frame.error_PINN_pp.iloc[peak])},
        'PINN_adaptive_log_weights':sigma.tolist(), 'PINN_loss_coefficients_exp_minus_sigma':np.exp(-sigma).tolist(),
        'PINN_Ea_kJ_per_mol':{'min':float(ea.min()/1000),'mean':float(ea.mean()/1000),'max':float(ea.max()/1000)},
        'late_validation_used_for_model_selection':True, 'single_physical_target_cell':True, 'seed':42,
        'blind_future_prediction_claimed':False, 'raw_targets':True,'prediction_postprocessing':False,
        'selection_audit':selection_audit,
    }
    frame.to_csv(ROOT/'50Ah_四模型_新划分_逐点预测.csv',index=False,encoding='utf-8-sig',float_format='%.17g')
    rows=[]
    for scope,models in by_split.items():
        for name,values in models.items(): rows.append({'split':scope,'model':name,**values})
    pd.DataFrame(rows).to_csv(ROOT/'50Ah_四模型_新划分_误差.csv',index=False,encoding='utf-8-sig')
    (ROOT/'metrics_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'overall':by_split['all_evaluation'],'late':by_split['late_evaluation'], 'diagnostics':diagnostic['all_evaluation']},indent=2))
    return report

if __name__=='__main__': evaluate()
