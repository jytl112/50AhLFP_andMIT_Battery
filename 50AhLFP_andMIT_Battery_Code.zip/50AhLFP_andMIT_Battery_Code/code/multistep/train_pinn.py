"""Select using prefix validation, then refit six prefix labels with fixed steps."""
import time
import numpy as np
import pandas as pd
from common import *

OUT=RESULTS/'PINN';OUT.mkdir(parents=True,exist_ok=True)

def run():
    operating,labels,x,replay,ci,config=load_development();scale=config['scale']
    train_cycles=[1,104,207,310];val_cycles=[412,515]
    ya=labels.set_index('Cycle').loc[train_cycles,'SOH'].to_numpy('float32')
    yv=labels.set_index('Cycle').loc[val_cycles,'SOH'].to_numpy('float32')
    val_ix=np.array(val_cycles)-1
    source=make_pinn(config,{'unfreeze':12},ya)
    teacher=source((replay[:,-1,:],np.zeros((64,1),'float32')),training=False)[0]
    del source
    proto={'model':'PINN','stage_A_train_cycles':train_cycles,'stage_A_validation_cycles':val_cycles,
           'stage_B_refit_cycles':labels.Cycle.tolist(),'physics_collocation_max_cycle':515,
           'candidates':PINN_CANDIDATES,'source_weights_sha256':sha(REFERENCE/'source_PINN/weights.weights.h5'),
           'heldout_target_file_read_by_training':False,'refit_steps_selected_before_test':True}
    save_json(OUT/'Protocol_before_training.json',proto)
    xc=tf.constant(x[ci]);xs=tf.constant(replay[:,-1,:])
    dn=tf.constant(np.diff(operating.Cycle.iloc[ci].to_numpy('float32'))[:,None])
    def train_candidate(choice,cycles,values,max_steps,use_validation):
        model=make_pinn(config,choice,values)
        sigma=[tf.Variable(v,dtype=tf.float32) for v in config['selected_log_weights']]
        variables=model.trainable_variables+sigma
        optimizer=keras.optimizers.Adam(choice['lr'],clipnorm=1.);optimizer.build(variables)
        xa=tf.constant(x[np.array(cycles)-1]);ys=tf.constant(((values-scale['y_min'])/scale['y_span'])[:,None],tf.float32)
        @tf.function
        def update():
            with tf.GradientTape() as tape:
                pa=model((xa,tf.zeros((len(cycles),1))),training=True)[0]
                ps=model((xs,tf.zeros((64,1))),training=True)[0]
                pred=model((xc,tf.zeros((65,1))),training=True)[0]
                acc=tf.stop_gradient(1.1*(1-(pred*scale['y_span']+scale['y_min'])/100))
                physical=model((xc,acc),training=True)[1]
                q=(pred*scale['y_span']+scale['y_min'])*1.1/100
                drop=tf.nn.relu(-(q[1:]-q[:-1])/dn)
                ea=model((xc,acc),training=True)[3]
                losses=[tf.reduce_mean((pa-ys)**2)+.01*tf.reduce_mean((ps-teacher)**2),
                        tf.reduce_mean((physical[1:]-drop)**2),
                        tf.reduce_mean(tf.nn.relu(ea-40000)+tf.nn.relu(28000-ea)),
                        tf.reduce_mean(((pred[1:]-pred[:-1])/dn)**2)]
                clipped=[tf.clip_by_value(v,-10,10) for v in sigma]
                total=tf.add_n([tf.exp(-v)*loss+v for v,loss in zip(clipped,losses)])
            gradients=tape.gradient(total,variables)
            tf.debugging.assert_all_finite(total,'nonfinite prefix-only loss')
            optimizer.apply_gradients([(g,v) for g,v in zip(gradients,variables) if g is not None])
            return tf.stack(losses)
        best=np.inf;stale=0;weights=None;best_sigma=None;selected=0;history=[]
        for step in range(1,max_steps+1):
            losses=update().numpy()
            if step==1 or step%20==0 or step==max_steps:
                row={'step':step,**{f'loss_{i}':float(v) for i,v in enumerate(losses)}}
                if use_validation:
                    val=float(np.mean(abs(pinn_predict(model,x[val_ix],scale)-yv)))
                    row['validation_MAE_pp']=val
                    if step>=200:
                        if val<best-1e-8:
                            best=val;stale=0;selected=step;weights=model.get_weights();best_sigma=[float(v.numpy()) for v in sigma]
                        else:stale+=1
                history.append(row)
                if use_validation and stale>=25:break
        if use_validation:
            assert weights is not None;model.set_weights(weights)
        else:
            selected=max_steps;best_sigma=[float(v.numpy()) for v in sigma]
        return model,history,{'selected_step':selected,'executed_steps':step,'validation_MAE_pp':best if use_validation else None,'selected_log_weights':best_sigma}
    records=[];started=time.perf_counter();best_global=np.inf;winner=None
    for index,choice in enumerate(PINN_CANDIDATES,1):
        print('PINN candidate',index,choice,flush=True)
        model,history,details=train_candidate(choice,train_cycles,ya,3500,True)
        folder=OUT/f'candidate_{index}';folder.mkdir(exist_ok=True)
        model.save_weights(folder/'selected.weights.h5')
        pd.DataFrame(history).to_csv(folder/'history.csv',index=False)
        row={'candidate':index,**choice,**details,'weight_sha256':sha(folder/'selected.weights.h5')}
        save_json(folder/'selection.json',row);records.append(row)
        if row['validation_MAE_pp']<best_global:best_global=row['validation_MAE_pp'];winner=row
        print('PINN done',row,'elapsed',round(time.perf_counter()-started,2),flush=True)
    pd.DataFrame(records).to_csv(OUT/'Validation_only_candidate_selection.csv',index=False)
    assert winner is not None
    save_json(OUT/'Selection_locked_before_refit.json',winner)
    all_y=labels.SOH.to_numpy('float32')
    model,history,refit=train_candidate(winner,labels.Cycle.tolist(),all_y,winner['selected_step'],False)
    model.save_weights(OUT/'final.weights.h5')
    pd.DataFrame(history).to_csv(OUT/'Refit_history_no_test_labels.csv',index=False)
    final={**proto,'selected_candidate':winner,'refit_updates':winner['selected_step'],
           'refit_log_weights':refit['selected_log_weights'],'final_weights_sha256':sha(OUT/'final.weights.h5'),
           'weights_frozen_at_cycle':515,'no_post515_label_use_for_any_selection_or_gradient':True,
           'parameter_count':model.count_params(),'elapsed_seconds':time.perf_counter()-started,
           'tensorflow':tf.__version__}
    save_json(OUT/'Final_training_protocol.json',final)
    print('PINN FINAL LOCKED',final,flush=True)

if __name__=='__main__':run()
