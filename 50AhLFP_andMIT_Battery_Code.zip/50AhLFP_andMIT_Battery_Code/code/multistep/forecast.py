"""Generate forecasts without opening any post-515 SOH/capacity labels."""
import numpy as np
import pandas as pd
from common import *

HORIZONS=(1,10,50)
NAMES=['PINN','LSTM','CNN','Transformer']

def generate():
    assert (RESULTS/'Baseline_training_summary.json').exists()
    _,labels,_,_,_,config=load_development();scale=config['scale']
    models={};locks=[]
    for name in NAMES:
        folder=RESULTS/name
        protocol=json.loads((folder/'Final_training_protocol.json').read_text(encoding='utf-8'))
        assert protocol['weights_frozen_at_cycle']==515
        assert protocol['no_post515_label_use_for_any_selection_or_gradient'] is True
        assert sha(folder/'final.weights.h5')==protocol['final_weights_sha256']
        winner=protocol['selected_candidate']
        choices=pd.read_csv(folder/('Validation_only_candidate_selection.csv' if name=='PINN' else 'Stage_A_candidates.csv'))
        best=choices.sort_values(['validation_MAE_pp','candidate']).iloc[0]
        assert len(choices)==12 and int(best.candidate)==winner['candidate']
        assert protocol['refit_updates']==winner['selected_step']
        if name=='PINN':model=make_pinn(config,winner,labels.SOH.to_numpy('float32'))
        else:
            model=build_model(name);model(np.zeros((2,8,6),'float32'))
        model.load_weights(folder/'final.weights.h5');models[name]=model
        locks.append({'model':name,'candidate':winner['candidate'],'final_weights_sha256':protocol['final_weights_sha256'],
                      'refit_updates':protocol['refit_updates']})
    save_json(RESULTS/'All_models_locked_before_forecasts.json',{'models':locks,'horizons':HORIZONS,
               'origins':[515,671],'count':157,'fixed_origin_diagnostic_tail':[516,721],
               'future_input_policy':'origin cumulative means held constant; cycle advances',
               'post515_capacity_labels_opened':False})
    operating=pd.read_csv(PACKAGE/'inputs/operating_inputs.csv')
    assert 'SOH' not in operating.columns and 'capacity' not in operating.columns
    # Perturb every future operating record to detect accidental future-input access.
    tests=[]
    for origin in [515,600,671]:
        endpoints,sequences=forecast_inputs(operating,scale,origin,HORIZONS)
        altered=operating.copy()
        altered.loc[altered.Cycle>origin,FEATURES[:-1]]=123456.0
        other_endpoints,other_sequences=forecast_inputs(altered,scale,origin,HORIZONS)
        assert np.array_equal(endpoints,other_endpoints) and np.array_equal(sequences,other_sequences)
        tests.append({'origin':origin,'arbitrary_future_operating_perturbation_changes_forecast_inputs':False})
    save_json(RESULTS/'Future_input_leakage_checks.json',tests)

    rows=[];endpoints=[];sequences=[]
    for origin in range(515,672):
        endpoint,sequence=forecast_inputs(operating,scale,origin,HORIZONS)
        endpoints.extend(endpoint);sequences.extend(sequence)
        for horizon in HORIZONS:
            rows.append({'origin_cycle':origin,'horizon':horizon,'target_cycle':origin+horizon,
                         'max_observed_operating_cycle':origin})
    endpoints=np.asarray(endpoints,dtype='float32');sequences=np.asarray(sequences,dtype='float32')
    frame=pd.DataFrame(rows)
    assert len(frame)==471 and (frame.groupby('horizon').size()==157).all()
    for name,model in models.items():
        if name=='PINN':prediction=pinn_predict(model,endpoints,scale)
        else:prediction=model(sequences,training=False).numpy().ravel()*scale['y_span']+scale['y_min']
        frame[f'SOH_{name}']=prediction.astype(float)
    linear=np.polyfit(labels.Cycle.to_numpy(float),labels.SOH.to_numpy(float),1)
    frame['SOH_six_label_OLS']=np.polyval(linear,frame.target_cycle)
    frame['SOH_sparse_persistence']=float(labels[labels.Cycle==515].SOH.iloc[0])
    frame.to_csv(RESULTS/'Forecasts_locked_before_raw_target_scoring.csv',index=False,float_format='%.17g')
    np.savez_compressed(RESULTS/'Forecast_input_vectors.npz',endpoints=endpoints,sequences=sequences)

    # Additional fixed-origin trace: all 206 future cycles use origin-515 information.
    tail_horizons=tuple(range(1,207))
    tail_x,tail_windows=forecast_inputs(operating,scale,515,tail_horizons)
    tail=pd.DataFrame({'origin_cycle':515,'horizon':tail_horizons,'target_cycle':np.arange(516,722)})
    for name,model in models.items():
        if name=='PINN':prediction=pinn_predict(model,tail_x,scale)
        else:prediction=model(tail_windows,training=False).numpy().ravel()*scale['y_span']+scale['y_min']
        tail[f'SOH_{name}']=prediction.astype(float)
    tail['SOH_six_label_OLS']=np.polyval(linear,tail.target_cycle)
    tail['SOH_origin515_persistence']=float(labels[labels.Cycle==515].SOH.iloc[0])
    tail.to_csv(RESULTS/'Fixed_origin515_tail_locked_before_scoring.csv',index=False,float_format='%.17g')
    save_json(RESULTS/'Forecast_generation_lock.json',{'models':locks,'rows':471,'origins':157,
               'horizons':HORIZONS,'linear_coefficients':linear.tolist(),
               'forecast_csv_sha256':sha(RESULTS/'Forecasts_locked_before_raw_target_scoring.csv'),
               'fixed_origin_tail_csv_sha256':sha(RESULTS/'Fixed_origin515_tail_locked_before_scoring.csv'),
               'heldout_raw_target_file_not_opened':True,
               'all_neural_forecasts_use_only_origin_available_operating_information':True})
    print('GENERATED_AND_LOCKED',len(frame),'forecasts, fixed-origin tail',len(tail),flush=True)

if __name__=='__main__':generate()
