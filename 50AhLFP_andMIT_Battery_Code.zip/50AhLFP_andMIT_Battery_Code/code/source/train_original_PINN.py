from pathlib import Path
from types import SimpleNamespace
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','3')
import time,json,hashlib,platform
import numpy as np,pandas as pd,tensorflow as tf
from tensorflow import keras
from Baseline_models import load_data,export_predictions,save_json,sha256,PROTOCOL
from Original_PINN_model import PD_PINN_Model_Strict
tf.get_logger().setLevel('ERROR')
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'source_PINN';OUT.mkdir(exist_ok=True)
arrays,scale=load_data(ROOT)
keras.utils.set_random_seed(42)
tf.config.experimental.enable_op_determinism()
scaler=SimpleNamespace(min_=np.array([-1-2*scale['feature_lo'][4]/scale['feature_span'][4]]),scale_=np.array([2/scale['feature_span'][4]]))
model=PD_PINN_Model_Strict(5,scaler,param_net_layers=12,param_net_hidden_dim=96,f_theta_layers=2,f_theta_hidden_dim=16)
model((arrays['x_train_seq'][:2,-1,:],arrays['physics_lprev'][:2]))
logvars=[tf.Variable(v,dtype=tf.float32) for v in [-10.,-5.,-5.,2.]]
schedule=keras.optimizers.schedules.ExponentialDecay(5e-5,1000,.92,staircase=True)
optimizer=keras.optimizers.Adam(schedule,clipnorm=1.)
trainables=model.trainable_variables+logvars;optimizer.build(trainables)
@tf.function(reduce_retracing=True)
def train_step(x,acc,y,mask):
    with tf.GradientTape() as tape:
        soh,physical,ap,ea,z=model((x,acc),training=True)
        pred_percent=soh*scale['y_span']+scale['y_min']
        q=pred_percent*1.1/100
        dq=q[1:]-q[:-1]
        lp=tf.nn.relu(-dq*mask[1:])
        losses=[tf.reduce_mean((y-soh)**2),tf.reduce_mean((physical[1:]*mask[1:]-lp)**2),
                tf.reduce_mean(tf.nn.relu(ea-40000)+tf.nn.relu(28000-ea)),
                tf.reduce_mean(((soh[1:]-soh[:-1])*mask[1:])**2)]
        sigma=[tf.clip_by_value(v,-10.,10.) for v in logvars]
        total=tf.add_n([tf.exp(-v)*loss+v for v,loss in zip(sigma,losses)])
    tf.debugging.assert_all_finite(total,'PINN nonfinite loss')
    optimizer.apply_gradients(zip(tape.gradient(total,trainables),trainables))
    return total,tf.stack(losses)

def predict(x):
    values=[]
    for j in range(0,len(x),2048):
        v=model((x[j:j+2048,-1,:],np.zeros((len(x[j:j+2048]),1),dtype='float32')),training=False)[0].numpy().ravel()
        values.append(v)
    return np.concatenate(values)*scale['y_span']+scale['y_min']

x=arrays['x_train_seq'][:,-1,:];y=arrays['y_train_scaled'];acc=arrays['physics_lprev'];mask=arrays['adjacent']
best=np.inf;stale=0;selected=0;history=[];started=time.perf_counter();weights=None;best_sigmas=None
print('START original PINN:12x96 +16x16;4 archived loss items;correct inverse temperature;source-only validation',flush=True)
for epoch in range(1,5001):
    batch=[]
    for j in range(0,len(x),512):
        total,losses=train_step(x[j:j+512],acc[j:j+512],y[j:j+512],mask[j:j+512]);batch.append(losses.numpy())
    prediction=predict(arrays['x_val_seq'])
    val=float(np.mean(np.abs(prediction-arrays['y_val_raw'].ravel())))
    if epoch>=150:
        if val<best-1e-9:
            best=val;selected=epoch;stale=0;weights=model.get_weights();best_sigmas=[float(v.numpy()) for v in logvars]
        else:stale+=1
    history.append({'epoch':epoch,'validation_raw_MAE_pp':val,'loss_soh':float(np.mean(batch,axis=0)[0]),
                    'loss_physics':float(np.mean(batch,axis=0)[1]),'loss_range':float(np.mean(batch,axis=0)[2]),
                    'loss_soh_smooth':float(np.mean(batch,axis=0)[3]),'elapsed_seconds':time.perf_counter()-started})
    if epoch%10==0 or epoch==1:
        pd.DataFrame(history).to_csv(OUT/'history.csv',index=False)
        print('PINN epoch',epoch,'source_validation_MAE',round(val,6),'elapsed',round(time.perf_counter()-started,1),flush=True)
    if epoch>=150 and stale>=80:break
assert weights is not None
model.set_weights(weights);model.save_weights(OUT/'weights.weights.h5')
pd.DataFrame(history).to_csv(OUT/'history.csv',index=False)
results={}
from Baseline_models import metrics
for role in ['val','test','target']:
    p=predict(arrays[f'x_{role}_seq'])
    frame=pd.DataFrame({'Battery_ID':arrays[f'battery_{role}'],'Cycle':arrays[f'cycle_{role}'],
                        'SOH_raw':arrays[f'y_{role}_raw'].ravel(),'SOH_base':p})
    frame.to_csv(OUT/f'{role}_predictions.csv',index=False,encoding='utf-8-sig')
    results[role]=metrics(frame.SOH_raw,frame.SOH_base)
# SOH forward output is independent of physical auxiliary capacity state.
test_x=arrays['x_target_seq'][:10,-1,:]
a=model((test_x,np.zeros((10,1),dtype='float32')))[0].numpy()
b=model((test_x,np.full((10,1),.9,dtype='float32')))[0].numpy()
assert np.array_equal(a,b)
cfg={'model':'PINN','protocol':PROTOCOL,'architecture':'original50AhNotebook:12x96tanh;SOHsigmoid;16x16Ftheta;singlephysicalheads',
     'parameter_count':model.count_params(),'source_inputs_sha256':sha256(ROOT/'source_inputs.npz'),
     'selected_joint_epoch':selected,'executed_joint_epochs':epoch,'best_validation_raw_MAE_pp':best,
     'elapsed_seconds':time.perf_counter()-started,'source_test_metrics':results['test'],
     'loss_items':['SOH_MSE','degradation_consistency','Ea_range','SOH_smoothness'],
     'adaptive_log_weight_initialization':[-10.,-5.,-5.,2.],'adaptive_log_weight_clip':[-10.,10.],
     'selected_log_weights':best_sigmas,'temperature_inverse_fix':'(T_scaled-min_)/scale_',
     'target_capacity_auxiliary_does_not_change_SOH_output':True,'scale':scale,'tensorflow':tf.__version__,
     'original5000fixed_epochs_replaced_by_shared_source_validation_selection':True,
     'not_original_Fig12_checkpoint':True,'training_target_label_use':False}
save_json(OUT/'config.json',cfg)
save_json(OUT/'prediction_metrics.json',results)
print('DONE original architecture PINN',json.dumps(results),flush=True)
