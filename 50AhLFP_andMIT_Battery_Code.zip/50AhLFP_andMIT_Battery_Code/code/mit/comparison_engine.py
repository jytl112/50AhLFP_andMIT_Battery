"""Auditable comparison preserving the manuscript's Arrhenius degradation law."""
from pathlib import Path
import os,json,time,hashlib,gc,platform
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','3')
os.environ.setdefault('PYTHONWARNINGS','ignore')
os.environ.setdefault('CUDA_VISIBLE_DEVICES','-1')
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
try:
    tf.config.threading.set_intra_op_parallelism_threads(2)
    tf.config.threading.set_inter_op_parallelism_threads(1)
except RuntimeError:pass
tf.get_logger().setLevel('ERROR')

ROOT=Path(os.environ.get('MODEL_COMPARE_DIR',Path(__file__).resolve().parents[1]))
OP=['V_fc_avg','I_fc_avg','V_d_avg','I_d_avg','Temperature']
FEATURES=OP+['Cycle','L_prev_Ah']
WINDOW=8
RUN_VERSION='arrhenius_matched_20261005_v2'

def write_json(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def scores(y,p):
    y=np.asarray(y,float).ravel();p=np.asarray(p,float).ravel();e=p-y
    assert len(y)==len(p) and len(y)>0 and np.isfinite(e).all()
    return {'n':len(y),'MAE_pp':float(np.mean(abs(e))),'RMSE_pp':float(np.sqrt(np.mean(e**2))),
            'MAPE_percent':float(100*np.mean(abs(e)/np.maximum(abs(y),1e-8))),
            'R2':float(1-np.sum(e**2)/np.sum((y-y.mean())**2)),
            'upward_fraction':float(np.mean(np.diff(p)>1e-6)) if len(p)>1 else 0.}

def scaler_fit(tr):
    x=tr.loc[tr.Initialized,FEATURES].to_numpy(float)
    lo=x.min(0);hi=x.max(0);span=np.where(hi==lo,1,hi-lo)
    sy=tr.loc[tr.Initialized,'SOH_target'].to_numpy(float)
    return {'lo':lo.tolist(),'span':span.tolist(),'y_min':float(sy.min()),'y_span':float(max(sy.max()-sy.min(),1))}

def windows(frame,scale):
    parts=[];seqs=[]
    for _,g in frame.groupby('Battery_ID',sort=True):
        g=g.sort_values('Cycle').reset_index(drop=True)
        x=(g[FEATURES].to_numpy(float)-np.asarray(scale['lo']))/np.asarray(scale['span'])*2-1
        for j in range(WINDOW-1,len(g)):
            if not bool(g.Initialized.iloc[j]):continue
            seqs.append(x[j-WINDOW+1:j+1]);parts.append(g.iloc[j])
    f=pd.DataFrame(parts).reset_index(drop=True)
    arr=np.asarray(seqs,'float32')
    assert arr.shape==(len(f),WINDOW,7) and np.isfinite(arr).all()
    y=((f.SOH_target.to_numpy(float)-scale['y_min'])/scale['y_span']).astype('float32')[:,None]
    adj=((f.Battery_ID==f.Battery_ID.shift())&(f.Cycle.diff()==1)).to_numpy('float32')[:,None]
    aux=np.column_stack([f.L_single_Ah.to_numpy(float),adj.ravel()]).astype('float32')
    return arr,y,aux,f

class PINN(keras.Model):
    def __init__(self,scale,nominal,use_physics=True):
        super().__init__();self.scale=scale;self.nominal=float(nominal);self.use_physics=use_physics
        self.base=keras.Sequential([keras.Input((7,))]+[keras.layers.Dense(64,activation='tanh') for _ in range(8)])
        self.soh=keras.layers.Dense(1,activation='sigmoid')
        self.a=keras.layers.Dense(1,activation='softplus');self.ea=keras.layers.Dense(1);self.z=keras.layers.Dense(1,activation='sigmoid')
        self.fnet=keras.Sequential([keras.Input((5,)),keras.layers.Dense(16,activation='tanh'),keras.layers.Dense(16,activation='tanh'),keras.layers.Dense(1,activation='softplus')])
        self.sigmas=self.add_weight(name='log_task_variances',shape=(4,),initializer='zeros',trainable=True)
    def call(self,seq,training=False):
        x=seq[:,-1,:];h=self.base(x,training=training);soh=self.soh(h);ph=tf.concat([h,soh],1)
        a=self.a(ph)+1e-12;ea=28000.+12000.*tf.sigmoid(self.ea(ph));z=.5+.5*self.z(ph);f=self.fnet(x[:,:5])+1e-12
        temp=(x[:,4:5]+1)/2*self.scale['span'][4]+self.scale['lo'][4]+273.15
        lag=(x[:,6:7]+1)/2*self.scale['span'][6]+self.scale['lo'][6]
        lag=tf.clip_by_value(lag,1e-8,self.nominal*(1-1e-8))
        logloss=tf.math.log(a)/z-ea/(8.314*temp*z)+tf.math.log(z)+(z-1)/z*tf.math.log(lag)+tf.math.log(self.nominal-lag)+tf.math.log(f)
        loss=tf.exp(tf.clip_by_value(logloss,-70.,30.))
        return soh,loss,ea,z

def build_model(name,scale,nominal):
    if name in ['PINN','MLP_NoPhysics']:return PINN(scale,nominal,name=='PINN')
    inputs=keras.Input((WINDOW,7))
    if name=='LSTM':
        h=keras.layers.LSTM(64)(inputs);h=keras.layers.Dropout(.1)(h)
    elif name=='CNN':
        h=keras.layers.Conv1D(64,3,padding='causal',activation='relu')(inputs)
        h=keras.layers.Conv1D(64,3,padding='causal',activation='relu')(h)
        h=keras.layers.GlobalAveragePooling1D()(h);h=keras.layers.Dropout(.1)(h)
    elif name=='Transformer':
        h=keras.layers.Dense(32)(inputs)
        pos=np.arange(WINDOW)[:,None];dims=np.arange(32)[None,:]
        angle=pos/10000.**(2*np.floor(dims/2)/32)
        pe=np.where(dims%2==0,np.sin(angle),np.cos(angle)).astype('float32')[None,:,:]
        h=h+tf.constant(pe)
        for _ in range(2):
            a=keras.layers.MultiHeadAttention(num_heads=4,key_dim=8,dropout=.1)(h,h,use_causal_mask=True)
            h=keras.layers.LayerNormalization(epsilon=1e-6)(h+a)
            a=keras.layers.Dense(64,activation='relu')(h);a=keras.layers.Dense(32)(a);a=keras.layers.Dropout(.1)(a)
            h=keras.layers.LayerNormalization(epsilon=1e-6)(h+a)
        h=keras.layers.GlobalAveragePooling1D()(h)
    else:raise ValueError(name)
    h=keras.layers.Dense(32,activation='relu')(h)
    return keras.Model(inputs,keras.layers.Dense(1,activation='sigmoid')(h),name=name)

def output(model,x):
    v=model(x,training=False)
    return v[0] if isinstance(v,tuple) else v

def inverse(p,scale):return np.asarray(p).ravel()*scale['y_span']+scale['y_min']

def objective(model,x,y,aux,joint):
    result=model(x,training=True)
    if isinstance(result,tuple):soh,loss,ea,z=result
    else:soh=result
    mse=tf.reduce_mean((soh-y)**2)
    if not joint or not isinstance(model,PINN):return mse,tf.stack([mse,0.,0.,0.])
    mask=aux[:,1:2];valid=mask*tf.cast(aux[:,0:1]>1e-8,tf.float32)
    physics=tf.reduce_sum(((tf.math.log(aux[:,0:1]+1e-10)-tf.math.log(loss+1e-10))/10)**2*valid)/tf.maximum(tf.reduce_sum(valid),1.)
    smooth_e=tf.reduce_sum(((ea[1:]-ea[:-1])/1000)**2*mask[1:])/tf.maximum(tf.reduce_sum(mask[1:]),1.)
    smooth_s=tf.reduce_sum((soh[1:]-soh[:-1])**2*mask[1:])/tf.maximum(tf.reduce_sum(mask[1:]),1.)
    terms=tf.stack([mse,physics,smooth_e,smooth_s]);sig=tf.clip_by_value(model.sigmas,-8.,8.)
    active=tf.constant([1.,1.,1.,1.] if model.use_physics else [1.,0.,0.,1.])
    return tf.reduce_sum(active*(tf.exp(-sig)*terms+sig)),terms

def train_candidate(name,scale,nominal,tr,va,seed,lr,out,protocol):
    out=Path(out);config_path=out/'config.json'
    signature=hashlib.sha256(json.dumps({'version':RUN_VERSION,'model':name,'scale':scale,'seed':seed,'lr':lr,'protocol':protocol},sort_keys=True).encode()).hexdigest()
    if config_path.exists():
        cfg=json.loads(config_path.read_text(encoding='utf-8'))
        if cfg.get('signature')==signature and (out/'weights.weights.h5').exists():return cfg
    out.mkdir(parents=True,exist_ok=True);keras.backend.clear_session();keras.utils.set_random_seed(seed)
    try:tf.config.experimental.enable_op_determinism()
    except (AttributeError,RuntimeError):pass
    model=build_model(name,scale,nominal);model(tr[0][:2]);params=model.count_params()
    best=np.inf;weights=None;best_phase=None;best_epoch=None;history=[];began=time.perf_counter()
    rng=np.random.default_rng(seed);bs=protocol['batch_size'];stale=0
    for phase,epochs,rate in [('warmup',protocol['warmup_epochs'],protocol['warmup_lr']),('joint',protocol['joint_epochs'],lr)]:
        optimizer=keras.optimizers.Adam(rate,clipnorm=protocol['clipnorm']);optimizer.build(model.trainable_variables)
        @tf.function(reduce_retracing=True)
        def train_step(xx,yy,aa):
            with tf.GradientTape() as tape:
                total,terms=objective(model,xx,yy,aa,phase=='joint')
            tf.debugging.assert_all_finite(total,'Nonfinite objective')
            grads=tape.gradient(total,model.trainable_variables)
            optimizer.apply_gradients([(g,v) for g,v in zip(grads,model.trainable_variables) if g is not None])
            if isinstance(model,PINN):model.sigmas.assign(tf.clip_by_value(model.sigmas,-8.,8.))
            return terms
        for epoch in range(epochs):
            values=[]
            for k in rng.permutation(np.arange(0,len(tr[0]),bs)):
                aa=tr[2][k:k+bs].copy();aa[0,1]=0
                values.append(train_step(tr[0][k:k+bs],tr[1][k:k+bs],aa).numpy())
            prediction=inverse(output(model,va[0]).numpy(),scale)
            mae=float(np.mean(abs(prediction-va[3].SOH_raw.to_numpy())))
            eligible=phase=='joint' and epoch+1>=protocol['min_joint_epochs']
            if eligible and mae<best-1e-9:
                best=mae;weights=model.get_weights();best_phase=phase;best_epoch=epoch+1;stale=0
            else:stale+=1
            row={'phase':phase,'epoch':epoch+1,'val_MAE_pp':mae}
            row.update(dict(zip(['soh','physics','Ea_smooth','SOH_smooth'],np.mean(values,axis=0).astype(float))))
            history.append(row)
            if phase=='joint' and epoch+1>=protocol['min_joint_epochs'] and stale>=protocol['patience']:break
    model.set_weights(weights);model.save_weights(out/'weights.weights.h5')
    pd.DataFrame(history).to_csv(out/'history.csv',index=False)
    cfg={'signature':signature,'version':RUN_VERSION,'model':name,'seed':seed,'lr':lr,'params':params,
         'best_val_MAE_pp':best,'selected_phase':best_phase,'selected_epoch':best_epoch,
         'executed_warmup':sum(r['phase']=='warmup' for r in history),'executed_joint':sum(r['phase']=='joint' for r in history),
         'elapsed_seconds':time.perf_counter()-began,'tensorflow':tf.__version__,'hardware':platform.platform(),
         'loss_weights':np.exp(-model.sigmas.numpy()).astype(float).tolist() if isinstance(model,PINN) else [1.,0.,0.,0.],
         'scale':scale,'protocol':protocol}
    if name=='MLP_NoPhysics':cfg['loss_weights'][1:3]=[0.,0.]
    write_json(config_path,cfg);del model;gc.collect();return cfg

def run_model(name,dataset_filter=None,limit=None):
    manifest=json.loads((ROOT/'inputs/manifest.json').read_text(encoding='utf-8'));protocol=manifest['protocol']
    frames={n:pd.read_csv(ROOT/'inputs'/f'{n}.csv') for n in sorted({f['dataset'] for f in manifest['folds'] if dataset_filter is None or f['dataset'] in dataset_filter})}
    rows=[];configs=[]
    folds=sorted([f for f in manifest['folds'] if dataset_filter is None or f['dataset'] in dataset_filter],key=lambda f:(f['dataset']=='MIT',f['dataset'],f['fold']))
    if limit:folds=folds[:limit]
    for fold in folds:
        dataset=fold['dataset'];f=frames[dataset];out=ROOT/'results'/name/dataset/fold['fold']
        train=f[f.Battery_ID.isin(fold['train_cells'])];val=f[f.Battery_ID==fold['validation_cell']];test=f[f.Battery_ID==fold['test_cell']]
        assert not set(train.Battery_ID)&set(val.Battery_ID) and not set(test.Battery_ID)&set(train.Battery_ID)
        scale=scaler_fit(train);tr=windows(train,scale);va=windows(val,scale);te=windows(test,scale)
        assert all(len(t[0]) for t in [tr,va,te])
        write_json(out/'split.json',{**fold,'scaler_fit_cells':sorted(train.Battery_ID.unique()),'n_train':len(tr[0]),'n_validation':len(va[0]),'n_test':len(te[0])})
        candidates=[]
        for lr in protocol['learning_rates']:
            path=out/f'seed42_lr{lr:g}'
            print('CANDIDATE',name,dataset,fold['fold'],lr,flush=True)
            candidates.append((train_candidate(name,scale,fold['nominal_Ah'],tr,va,42,lr,path,protocol),path))
        selected,path=min(candidates,key=lambda x:x[0]['best_val_MAE_pp'])
        write_json(out/'selection.json',{'criterion':'validation raw MAE','learning_rate':selected['lr'],'candidates':[c for c,p in candidates],'test_used_for_selection':False})
        for seed in protocol['seeds']:
            runpath=path if seed==42 else out/f'seed{seed}_lr{selected["lr"]:g}'
            cfg=selected if seed==42 else train_candidate(name,scale,fold['nominal_Ah'],tr,va,seed,selected['lr'],runpath,protocol)
            keras.backend.clear_session();model=build_model(name,scale,fold['nominal_Ah']);model(te[0][:2]);model.load_weights(runpath/'weights.weights.h5')
            pred=inverse(output(model,te[0]).numpy(),scale)
            record={'model':name,'dataset':dataset,'fold':fold['fold'],'test_cell':fold['test_cell'],'seed':seed,**scores(te[3].SOH_raw,pred)}
            table=te[3][['Battery_ID','Cycle','SOH_raw','SOH_target','Persistence_raw_pp']].copy();table['SOH_prediction']=pred
            if isinstance(model,PINN):
                v=model(te[0],training=False);table['predicted_increment_Ah']=v[1].numpy().ravel();table['Ea_J_mol']=v[2].numpy().ravel();table['z']=v[3].numpy().ravel()
                if name=='PINN':assert table.Ea_J_mol.between(28000,40000).all() and table.z.between(.5,1).all() and (table.predicted_increment_Ah>=0).all()
            table.to_csv(runpath/'test_predictions.csv',index=False,encoding='utf-8-sig')
            write_json(runpath/'test_metrics.json',record);rows.append(record)
            configs.append({**cfg,'dataset':dataset,'fold':fold['fold'],'test_cell':fold['test_cell']})
            print('DONE',name,dataset,fold['fold'],'seed',seed,'MAPE',round(record['MAPE_percent'],6),'seconds',round(cfg['elapsed_seconds'],1),flush=True)
            del model;gc.collect()
        pd.DataFrame(rows).to_csv(ROOT/f'{name}_metrics.csv',index=False)
        write_json(ROOT/f'{name}_configs.json',configs)
    return pd.DataFrame(rows)

if __name__=='__main__':
    import sys
    name=sys.argv[1];filters=sys.argv[2].split(',') if len(sys.argv)>2 else None
    result=run_model(name,filters)
    print(result.groupby('dataset')[['MAE_pp','MAPE_percent']].mean().to_string(),flush=True)
