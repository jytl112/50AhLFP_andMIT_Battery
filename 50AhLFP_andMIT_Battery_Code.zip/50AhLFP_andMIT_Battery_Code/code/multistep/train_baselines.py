"""Prefix-only model selection and six-label refit for frozen forecasts.

No post-515 operating records or SOH labels are opened by this script. All
forecast scoring belongs to the separate evaluator, after checkpoints lock.
"""
from pathlib import Path
import datetime
import json
import time

from common import (
    np, pd, tf, keras, PACKAGE, RESULTS, REFERENCE, build_model,
    BASELINE_CANDIDATES, load_development, windows8, sha, save_json,
)


TRAIN_CYCLES = [1, 104, 207, 310]
VALIDATION_CYCLES = [412, 515]
REFIT_CYCLES = TRAIN_CYCLES + VALIDATION_CYCLES
MAXIMUM_UPDATES = 3500
VALIDATION_EVERY = 20
MINIMUM_ELIGIBLE_UPDATE = 200
PATIENCE_CHECKS = 25
RETENTION_WEIGHT = 0.01


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def make_model(name, choice, label_values, scale):
    keras.utils.set_random_seed(42)
    model = build_model(name)
    model(np.zeros((2, 8, 6), dtype="float32"), training=False)
    model.load_weights(REFERENCE / f"source_{name}" / "weights.weights.h5")
    if choice.get("reset_head"):
        head = model.get_layer("SOH_scaled")
        level = np.clip(
            float(np.mean((np.asarray(label_values) - scale["y_min"]) / scale["y_span"])),
            1e-4, 1 - 1e-4,
        )
        head.kernel.assign(tf.zeros_like(head.kernel))
        head.bias.assign([np.log(level / (1 - level))])
    for layer in model.layers:
        layer.trainable = choice["scope"] == "all" or layer.name in ["dense32", "SOH_scaled"]
    return model


def make_update(model, supervised_x, supervised_y, replay_x, teacher, learning_rate):
    optimizer = keras.optimizers.Adam(learning_rate, clipnorm=1.0)
    optimizer.build(model.trainable_variables)

    @tf.function
    def update():
        with tf.GradientTape() as tape:
            predicted = model(supervised_x, training=True)
            replay_predicted = model(replay_x, training=True)
            data_loss = tf.reduce_mean((predicted - supervised_y) ** 2)
            retention_loss = tf.reduce_mean((replay_predicted - teacher) ** 2)
            loss = data_loss + RETENTION_WEIGHT * retention_loss
        tf.debugging.assert_all_finite(loss, "Nonfinite prefix-only baseline loss")
        gradients = tape.gradient(loss, model.trainable_variables)
        for gradient in gradients:
            if gradient is not None:
                tf.debugging.assert_all_finite(gradient, "Nonfinite baseline gradient")
        optimizer.apply_gradients(
            [(gradient, variable) for gradient, variable in zip(gradients, model.trainable_variables)
             if gradient is not None]
        )
        return loss, data_loss, retention_loss

    return update


def execute():
    operating, labels, x, replay, _, config = load_development()
    scale = config["scale"]
    assert operating.Cycle.tolist() == list(range(1, 516))
    assert labels.Cycle.tolist() == REFIT_CYCLES
    windows = windows8(x)
    label_lookup = labels.set_index("Cycle")["SOH"]
    training_values = label_lookup.loc[TRAIN_CYCLES].to_numpy("float32")
    validation_values = label_lookup.loc[VALIDATION_CYCLES].to_numpy("float32")
    refit_values = label_lookup.loc[REFIT_CYCLES].to_numpy("float32")
    xs = tf.constant(replay)
    train_x = tf.constant(windows[np.asarray(TRAIN_CYCLES) - 1])
    train_y = tf.constant(((training_values - scale["y_min"]) / scale["y_span"])[:, None])
    validation_x = windows[np.asarray(VALIDATION_CYCLES) - 1]
    refit_x = tf.constant(windows[np.asarray(REFIT_CYCLES) - 1])
    refit_y = tf.constant(((refit_values - scale["y_min"]) / scale["y_span"])[:, None])
    RESULTS.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    summaries = []

    for name in ["LSTM", "CNN", "Transformer"]:
        model_started = time.perf_counter()
        out = RESULTS / name
        out.mkdir(parents=True, exist_ok=True)
        source_weight_path = REFERENCE / f"source_{name}" / "weights.weights.h5"
        source_model = make_model(name, {"scope": "all", "lr": 1e-5}, training_values, scale)
        teacher = tf.stop_gradient(source_model(xs, training=False))
        source_protocol = {
            "model": name,
            "experiment": "retrospective_chronological_multistep_frozen_at_515",
            "source": "MIT Batch1 38 train, b1c17 validation, b1c43 test; existing source checkpoint",
            "source_weights_sha256": sha(source_weight_path),
            "source_config_sha256": sha(REFERENCE / f"source_{name}" / "config.json"),
            "source_replay_sha256": sha(REFERENCE / "source_training_operating_inputs.npz"),
            "prefix_operating_sha256": sha(PACKAGE / "inputs" / "prefix_operating_inputs.csv"),
            "six_prefix_labels_sha256": sha(PACKAGE / "inputs" / "six_prefix_labels.csv"),
            "stage_A_supervised_cycles": TRAIN_CYCLES,
            "stage_A_validation_cycles": VALIDATION_CYCLES,
            "stage_B_refit_supervised_cycles": REFIT_CYCLES,
            "candidate_settings_prespecified": BASELINE_CANDIDATES,
            "candidate_count": len(BASELINE_CANDIDATES),
            "maximum_updates": MAXIMUM_UPDATES,
            "validation_check_every": VALIDATION_EVERY,
            "minimum_eligible_update": MINIMUM_ELIGIBLE_UPDATE,
            "patience_checks": PATIENCE_CHECKS,
            "candidate_selection": "minimum stage-A raw SOH validation MAE in percentage points",
            "stage_B_training_duration": "fixed stage-A selected step; no validation or early stopping",
            "seed": 42,
            "optimizer": "Adam",
            "gradient_clipnorm": 1.0,
            "loss": "scaled target SOH MSE + 0.01 source teacher retention MSE",
            "source_retention_weight": RETENTION_WEIGHT,
            "source_retention_points": int(len(replay)),
            "input_window": 8,
            "early_history_padding": "repeat first observed input; no future inputs",
            "prefix_operating_max_cycle": int(operating.Cycle.max()),
            "scale": scale,
            "no_target_scaler_refit": True,
            "target_current_mapping": "source-equivalent amperes; multiply 1.1/50",
            "target_labels_smoothed": False,
            "prediction_smoothing": False,
            "post_prediction_correction": False,
            "post515_operating_used_for_training_or_selection": False,
            "post515_SOH_used_for_training_or_selection": False,
            "protocol_written_UTC": utc_now(),
        }
        save_json(out / "Protocol_before_training.json", source_protocol)
        candidate_records = []
        best_overall = np.inf
        winner = None

        for number, choice in enumerate(BASELINE_CANDIDATES, 1):
            model = make_model(name, choice, training_values, scale)
            update = make_update(model, train_x, train_y, xs, teacher, choice["lr"])
            best = np.inf
            stale = 0
            best_weights = None
            selected_step = 0
            history = []
            print(name, "STAGE_A_CANDIDATE", number, choice, flush=True)

            for step in range(1, MAXIMUM_UPDATES + 1):
                loss, data_loss, retention_loss = [float(v.numpy()) for v in update()]
                if step == 1 or step % VALIDATION_EVERY == 0:
                    predicted = model(validation_x, training=False).numpy().ravel()
                    predicted = predicted * scale["y_span"] + scale["y_min"]
                    validation_mae = float(np.mean(np.abs(predicted - validation_values)))
                    history.append({
                        "step": step, "loss": loss, "data_loss": data_loss,
                        "retention_loss": retention_loss, "validation_MAE_pp": validation_mae,
                    })
                    if step >= MINIMUM_ELIGIBLE_UPDATE:
                        if validation_mae < best - 1e-8:
                            best = validation_mae
                            stale = 0
                            selected_step = step
                            best_weights = model.get_weights()
                        else:
                            stale += 1
                    if step % 400 == 0:
                        print(name, number, step, "validation_MAE_pp", round(validation_mae, 6),
                              "elapsed_s", round(time.perf_counter() - started, 1), flush=True)
                    if stale >= PATIENCE_CHECKS:
                        break

            assert best_weights is not None and selected_step >= MINIMUM_ELIGIBLE_UPDATE
            model.set_weights(best_weights)
            candidate_dir = out / f"candidate_{number}"
            candidate_dir.mkdir(parents=True, exist_ok=True)
            model.save_weights(candidate_dir / "weights.weights.h5")
            row = {
                "candidate": number, **choice, "selected_step": selected_step,
                "executed_steps": step, "validation_MAE_pp": best,
                "weights_sha256": sha(candidate_dir / "weights.weights.h5"),
                "trainable_parameters": int(sum(np.prod(v.shape) for v in model.trainable_variables)),
            }
            candidate_records.append(row)
            pd.DataFrame(history).to_csv(candidate_dir / "history.csv", index=False)
            save_json(candidate_dir / "config.json", row)
            pd.DataFrame(candidate_records).to_csv(out / "Stage_A_candidates.csv", index=False)
            pd.DataFrame(candidate_records).to_csv(out / "Validation_only_candidate_selection.csv", index=False)
            if best < best_overall:
                best_overall = best
                winner = row.copy()
            print(name, "STAGE_A_CANDIDATE_DONE", row, flush=True)

        assert winner is not None
        save_json(out / "Stage_A_selected_candidate.json", winner)
        selected_choice = BASELINE_CANDIDATES[winner["candidate"] - 1]
        # The six-label fit starts again from the unchanged MIT checkpoint.
        # The stage-A selected checkpoint is deliberately not the refit start.
        final_model = make_model(name, selected_choice, refit_values, scale)
        refit_update = make_update(final_model, refit_x, refit_y, xs, teacher, selected_choice["lr"])
        refit_history = []
        refit_updates = int(winner["selected_step"])
        print(name, "STAGE_B_REFIT_BEGIN", "fixed_updates", refit_updates, flush=True)
        for step in range(1, refit_updates + 1):
            loss, data_loss, retention_loss = [float(v.numpy()) for v in refit_update()]
            if step == 1 or step % 20 == 0 or step == refit_updates:
                refit_history.append({"step": step, "loss": loss, "data_loss": data_loss,
                                      "retention_loss": retention_loss})
            if step % 400 == 0:
                print(name, "STAGE_B_REFIT", step, "loss", round(loss, 9), flush=True)
        final_path = out / "final.weights.h5"
        final_model.save_weights(final_path)
        pd.DataFrame(refit_history).to_csv(out / "Stage_B_refit_history.csv", index=False)
        final_protocol = {
            **source_protocol,
            "selected_candidate": winner,
            "refit_updates": refit_updates,
            "refit_start": "unchanged MIT source checkpoint",
            "head_reset_initialization": "six prefix supervised labels, only when selected candidate resets head",
            "refit_early_stopping": False,
            "refit_validation_used": False,
            "weights_frozen_at_cycle": 515,
            "no_post515_label_use_for_any_selection_or_gradient": True,
            "parameter_count": int(final_model.count_params()),
            "trainable_parameter_count": int(sum(np.prod(v.shape) for v in final_model.trainable_variables)),
            "final_weights_sha256": sha(final_path),
            "final_checkpoint_written_UTC": utc_now(),
            "wall_seconds": time.perf_counter() - model_started,
        }
        save_json(out / "Final_training_protocol.json", final_protocol)
        summaries.append({
            "model": name, "selected_candidate": winner,
            "refit_updates": refit_updates, "weights_frozen_at_cycle": 515,
            "final_weights_sha256": final_protocol["final_weights_sha256"],
            "parameter_count": final_protocol["parameter_count"],
            "no_post515_label_use_for_any_selection_or_gradient": True,
            "wall_seconds": final_protocol["wall_seconds"],
        })
        print(name, "FINAL_CHECKPOINT_LOCKED", summaries[-1], flush=True)

    save_json(RESULTS / "Baseline_training_summary.json", {
        "models": summaries, "wall_seconds": time.perf_counter() - started,
        "completed_UTC": utc_now(), "all_models_frozen_at_cycle": 515,
        "test_labels_opened": False,
    })
    print("ALL_BASELINES_LOCKED", "wall_seconds", round(time.perf_counter() - started, 1), flush=True)


if __name__ == "__main__":
    execute()
