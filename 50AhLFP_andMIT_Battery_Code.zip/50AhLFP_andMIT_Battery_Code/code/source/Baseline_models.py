"""Six-input source-domain baselines with a shared held-cell validation rule.

This module trains only on MIT Batch 1 source data. Target labels are never
used by a source network, scaler, checkpoint selector, or prediction routine.
Frozen source predictions are exported for the separately managed common
four-parameter target correction. The MLP is a data-only matched backbone.
"""
from pathlib import Path
import os
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL','3')
os.environ.setdefault('CUDA_VISIBLE_DEVICES','-1')
os.environ.setdefault('PYTHONWARNINGS','ignore')
import json,time,hashlib,platform,argparse
import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow import keras
try:
    tf.config.threading.set_intra_op_parallelism_threads(2)
    tf.config.threading.set_inter_op_parallelism_threads(1)
except RuntimeError:
    pass
tf.get_logger().setLevel('ERROR')

HERE=Path(__file__).resolve().parent
FEATURES=['V_fc_avg','I_fc_avg','V_d_avg','I_d_avg','Temperature','Cycle']
MODELS=['MLP','LSTM','CNN','Transformer']
PROTOCOL={
    'version':'original_climate_source_comparison_20261007_v5',
    'source':'MIT Batch1:38 training cells, b1c17 validation, b1c43 test',
    'feature_count':6,'window':8,'features':FEATURES,'operating_feature_transform':'within-cell cumulative mean','learning_rate_schedule':'ExponentialDecay:1000updates,0.92,staircase',
    'target_labels_used_in_source_training':False,
    'source_checkpoint_selected_by_target_data':False,
    'seed':42,'optimizer':'Adam','clipnorm':1.,'batch_size':512,
    'warmup_epochs':0,'warmup_lr':8e-4,
    'joint_epochs_max':5000,'joint_lr':5e-5,'minimum_joint_epochs':150,
    'patience':80,'checkpoint_criterion':'validation raw SOH MAE in percentage points',
    'loss':'SOH scaled mean squared error, fixed weight1',
    'architecture_selection':'prespecified, not selected using target data',
    'target_adaptation':'none within this source training module; frozen predictions only',
    'postprocessing':'none before metrics; no clipping, smoothing or monotone projection',
    'seed_limit':'one source initialization; no significance or robust ranking claim',
}

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save_json(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')

def build_model(name):
    """The MLP reads the endpoint; sequence models read the same eight-record window."""
    if name not in MODELS:
        raise ValueError(name)
    inputs=keras.Input((8,6),name='six_input_causal_window')
    if name=='MLP':
        h=keras.layers.Lambda(lambda a:a[:,-1,:],name='endpoint_only')(inputs)
        for i in range(8):
            h=keras.layers.Dense(64,activation='tanh',name=f'mlp_dense_{i+1}')(h)
    elif name=='LSTM':
        h=keras.layers.LSTM(64,name='lstm64')(inputs)
        h=keras.layers.Dropout(.1,name='lstm_dropout')(h)
        h=keras.layers.Dense(32,activation='relu',name='dense32')(h)
    elif name=='CNN':
        h=keras.layers.Conv1D(64,3,padding='causal',activation='relu',name='causal_conv1')(inputs)
        h=keras.layers.Conv1D(64,3,padding='causal',activation='relu',name='causal_conv2')(h)
        h=keras.layers.GlobalAveragePooling1D(name='temporal_mean')(h)
        h=keras.layers.Dropout(.1,name='cnn_dropout')(h)
        h=keras.layers.Dense(32,activation='relu',name='dense32')(h)
    else:
        h=keras.layers.Dense(32,name='input_projection32')(inputs)
        pos=np.arange(8)[:,None];dims=np.arange(32)[None,:]
        angle=pos/10000.**(2*np.floor(dims/2)/32)
        pe=np.where(dims%2==0,np.sin(angle),np.cos(angle)).astype('float32')[None,:,:]
        h=h+tf.constant(pe)
        for i in range(2):
            a=keras.layers.MultiHeadAttention(num_heads=4,key_dim=8,dropout=.1,name=f'causal_attention{i+1}')(h,h,use_causal_mask=True)
            h=keras.layers.LayerNormalization(epsilon=1e-6,name=f'attention_norm{i+1}')(h+a)
            a=keras.layers.Dense(64,activation='relu',name=f'ffn64_{i+1}')(h)
            a=keras.layers.Dense(32,name=f'ffn32_{i+1}')(a)
            a=keras.layers.Dropout(.1,name=f'ffn_dropout{i+1}')(a)
            h=keras.layers.LayerNormalization(epsilon=1e-6,name=f'ffn_norm{i+1}')(h+a)
        h=keras.layers.GlobalAveragePooling1D(name='temporal_mean')(h)
        h=keras.layers.Dense(32,activation='relu',name='dense32')(h)
    return keras.Model(inputs,keras.layers.Dense(1,activation='sigmoid',name='SOH_scaled')(h),name=name)

def metrics(raw,pred):
    raw=np.asarray(raw,float).reshape(-1);pred=np.asarray(pred,float).reshape(-1)
    e=pred-raw
    return dict(n=len(e),MAE_pp=float(np.mean(np.abs(e))),RMSE_pp=float(np.sqrt(np.mean(e**2))),
                MAPE_percent=float(100*np.mean(np.abs(e)/np.maximum(np.abs(raw),1e-8))),
                R2=float(1-np.sum(e**2)/np.sum((raw-raw.mean())**2)))

def batched_prediction(model,x,scale):
    parts=[]
    for j in range(0,len(x),2048):
        parts.append(model(x[j:j+2048],training=False).numpy().reshape(-1))
    return np.concatenate(parts)*float(scale['y_span'])+float(scale['y_min'])

def load_data(root=HERE):
    root=Path(root)
    with np.load(root/'source_inputs.npz',allow_pickle=False) as n:
        arrays={k:n[k].copy() for k in n.files}
    scale=json.loads((root/'source_scale.json').read_text(encoding='utf-8'))
    for part in ['train','val','test','target']:
        x=arrays[f'x_{part}_seq']
        assert x.ndim==3 and tuple(x.shape[1:])==(8,6) and np.isfinite(x).all(),(part,x.shape)
        arrays[f'x_{part}_seq']=x.astype('float32')
    arrays['y_train_scaled']=arrays['y_train_scaled'].astype('float32').reshape(-1,1)
    assert len(arrays['y_train_scaled'])==len(arrays['x_train_seq'])
    assert np.isfinite(arrays['y_train_scaled']).all()
    assert list(scale.get('feature_columns',FEATURES))==FEATURES
    assert float(scale['y_span'])>0
    return arrays,scale

def export_predictions(model,arrays,scale,out):
    result={}
    for part in ['val','test','target']:
        p=batched_prediction(model,arrays[f'x_{part}_seq'],scale)
        raw=np.asarray(arrays[f'y_{part}_raw']).reshape(-1)
        f=pd.DataFrame({'Cycle':np.asarray(arrays[f'cycle_{part}']).reshape(-1),'SOH_raw':raw,'SOH_base':p})
        if f'battery_{part}' in arrays:
            f.insert(0,'Battery_ID',np.asarray(arrays[f'battery_{part}']).astype(str).reshape(-1))
        else:
            f.insert(0,'Battery_ID','LFP_50Ah_Cell_01' if part=='target' else part)
        if part=='target':
            f['partition_code']=np.asarray(arrays['split_target']).reshape(-1)
            f['partition']=f['partition_code'].map({0:'calibration',1:'validation',2:'test'})
        f.to_csv(out/f'{part}_predictions.csv',index=False,encoding='utf-8-sig')
        if part!='target':
            result[part]=metrics(raw,p)
        else:
            # Target metrics are descriptive zero-shot scores only. They never
            # select a source checkpoint or any adaptation setting here.
            result['target_zero_shot']={lab:metrics(g.SOH_raw,g.SOH_base) for lab,g in f.groupby('partition')}
    save_json(out/'prediction_metrics.json',result)
    return result

def run(name,root=HERE,force=False):
    root=Path(root);out=root/f'source_{name}';out.mkdir(parents=True,exist_ok=True)
    arrays,scale=load_data(root)
    fingerprint={'source_inputs_sha256':sha256(root/'source_inputs.npz'),'source_scale_sha256':sha256(root/'source_scale.json')}
    signature=hashlib.sha256(json.dumps({'model':name,'protocol':PROTOCOL,**fingerprint},sort_keys=True).encode()).hexdigest()
    keras.backend.clear_session();keras.utils.set_random_seed(PROTOCOL['seed'])
    try:tf.config.experimental.enable_op_determinism()
    except (AttributeError,RuntimeError):pass
    model=build_model(name);model(arrays['x_train_seq'][:2])
    config_path=out/'config.json'
    if config_path.exists():
        cfg=json.loads(config_path.read_text(encoding='utf-8'))
        if not force and cfg.get('signature')==signature and (out/'weights.weights.h5').exists():
            model.load_weights(out/'weights.weights.h5')
            result=export_predictions(model,arrays,scale,out)
            print('CACHED',name,json.dumps(result['test']),flush=True)
            return cfg
    x=arrays['x_train_seq'];y=arrays['y_train_scaled'];rng=np.random.default_rng(PROTOCOL['seed'])
    best=float('inf');selected=None;best_weights=None;stale=0;hist=[];began=time.perf_counter()
    print('START',name,'params',model.count_params(),'train',len(x),'val',len(arrays['x_val_seq']),flush=True)
    for phase,epochs,rate in [('warmup',PROTOCOL['warmup_epochs'],PROTOCOL['warmup_lr']),('joint',PROTOCOL['joint_epochs_max'],PROTOCOL['joint_lr'])]:
        schedule=keras.optimizers.schedules.ExponentialDecay(rate,1000,.92,staircase=True)
        opt=keras.optimizers.Adam(schedule,clipnorm=PROTOCOL['clipnorm'])
        opt.build(model.trainable_variables)
        @tf.function(reduce_retracing=True)
        def train_step(xx,yy):
            with tf.GradientTape() as tape:
                predicted=model(xx,training=True)
                loss=tf.reduce_mean(tf.square(predicted-yy))
            tf.debugging.assert_all_finite(loss,'nonfinite SOH MSE')
            opt.apply_gradients(zip(tape.gradient(loss,model.trainable_variables),model.trainable_variables))
            return loss
        for epoch in range(1,epochs+1):
            chunks=[]
            order=np.arange(len(x))
            for j in range(0,len(x),PROTOCOL['batch_size']):
                ix=order[j:j+PROTOCOL['batch_size']]
                chunks.append(float(train_step(x[ix],y[ix]).numpy()))
            p=batched_prediction(model,arrays['x_val_seq'],scale)
            val_mae=float(np.mean(abs(p-arrays['y_val_raw'].reshape(-1))))
            eligible=phase=='joint' and epoch>=PROTOCOL['minimum_joint_epochs']
            if eligible:
                if val_mae<best-1e-9:
                    best=val_mae;selected=epoch;best_weights=model.get_weights();stale=0
                else:stale+=1
            hist.append({'phase':phase,'epoch':epoch,'train_scaled_MSE':float(np.mean(chunks)),
                         'validation_raw_MAE_pp':val_mae,'checkpoint_eligible':eligible,'elapsed_seconds':time.perf_counter()-began})
            if epoch%10==0 or epoch==1:
                pd.DataFrame(hist).to_csv(out/'history.csv',index=False)
                print(name,phase,'epoch',epoch,'val_MAE',round(val_mae,6),'elapsed',round(time.perf_counter()-began,1),flush=True)
            if eligible and stale>=PROTOCOL['patience']:
                break
    assert selected is not None and selected>=PROTOCOL['minimum_joint_epochs']
    model.set_weights(best_weights);model.save_weights(out/'weights.weights.h5')
    pd.DataFrame(hist).to_csv(out/'history.csv',index=False)
    cfg={'model':name,'signature':signature,'protocol':PROTOCOL,**fingerprint,'scale':scale,
         'parameter_count':model.count_params(),'selected_joint_epoch':selected,'best_validation_raw_MAE_pp':best,
         'executed_warmup_epochs':sum(h['phase']=='warmup' for h in hist),'executed_joint_epochs':sum(h['phase']=='joint' for h in hist),
         'elapsed_seconds':time.perf_counter()-began,'tensorflow':tf.__version__,'platform':platform.platform(),
         'target_network_fine_tuning':False,'target_correction_fitted':False,'capacity_or_soh_forward_input':False}
    result=export_predictions(model,arrays,scale,out)
    cfg['source_test_metrics']=result['test']
    save_json(config_path,cfg)
    print('DONE',name,json.dumps({'test':result['test'],'seconds':cfg['elapsed_seconds'],'epoch':selected}),flush=True)
    return cfg

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('model',choices=MODELS);parser.add_argument('--root',type=Path,default=HERE)
    parser.add_argument('--force',action='store_true',help='Retrain source model using the same prespecified settings.')
    args=parser.parse_args();run(args.model,args.root,force=args.force)
